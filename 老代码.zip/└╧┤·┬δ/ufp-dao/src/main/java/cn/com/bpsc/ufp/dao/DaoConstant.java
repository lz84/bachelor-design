/*
 * @(#)DaoConstant.java	May 31, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.dao;

/**
 * @author 胡斌
 *
 */
public class DaoConstant {

	public static String PAGE_INFO = "ufp_dao_page_info";
}
