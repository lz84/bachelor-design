/*
 * @(#)BusinessDomainDaoImpl.java	Mar 26, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.dao.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import cn.com.bpsc.ufp.dao.impl.GenericDaoImpl;
import cn.com.bpsc.ufp.ps.dao.IBusinessDomainDao;
import cn.com.bpsc.ufp.ps.domain.BusinessDomain;

/**
 * @author user
 *
 */
@Repository
public class BusinessDomainDaoImpl extends GenericDaoImpl<BusinessDomain, String>   implements IBusinessDomainDao {

	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.dao.IBusinessDomainDao#findChildren(java.lang.String)
	 */
	@Override
	public List<BusinessDomain> findChildren(String parentId) {
		String hql = "from BusinessDomain ";
		if(StringUtils.isEmpty(parentId)){
			hql += " where parent is null";
		}else{
			hql += " where parent.id = '" + parentId + "'";
		}
		
		return super.findByHQL(hql);
	}

	

}
