package cn.com.bpsc.ufp.stat.dao;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.stat.domain.StatUserTrack;

public interface IStatUserTrackDao extends IGenericDao<StatUserTrack, String> {
 
}
