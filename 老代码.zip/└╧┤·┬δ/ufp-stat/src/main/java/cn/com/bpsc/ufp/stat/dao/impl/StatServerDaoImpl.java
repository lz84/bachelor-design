package cn.com.bpsc.ufp.stat.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import cn.com.bpsc.ufp.dao.impl.GenericDaoImpl;
import cn.com.bpsc.ufp.stat.dao.IStatServerDao;
import cn.com.bpsc.ufp.stat.domain.StatServer;

@Repository
public class StatServerDaoImpl  extends GenericDaoImpl<StatServer,String> implements IStatServerDao{

	@Override
	public List<StatServer> findByExample(StatServer ss) {
		StringBuilder qSQL = new StringBuilder();
		qSQL.append(" from StatServer where 1=1 ");
		if(ss!=null){
			if(ss.getIpAddr()!=null && !"".equals(ss.getIpAddr())){
				qSQL.append(" and ipAddr='").append(ss.getIpAddr()).append("'");
			}
			if(ss.getSearchType()!=null && ss.getSearchType().trim().equals("search")){
				qSQL.append(" and shutdownTime is null ");
			}
		}
		qSQL.append(" order by startTime desc ");
		Query query  = getSession().createQuery(qSQL.toString());
		return query.list();
	}

}
