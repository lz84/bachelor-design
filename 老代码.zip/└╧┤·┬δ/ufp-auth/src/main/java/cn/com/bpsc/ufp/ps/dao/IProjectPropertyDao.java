/*
 * @(#)IProjectPropertyDao.java	Mar 8, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.dao;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.ps.domain.ProjectProperty;

/**
 * @author 胡斌
 *
 */
public interface IProjectPropertyDao extends IGenericDao<ProjectProperty, String>{

}
