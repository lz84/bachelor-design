/*
 * @(#)IGvDao.java	2013-3-4
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.gv.dao;

import java.util.List;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.gv.domain.GlobalVariable;

/**
 * @author 胡斌
 *
 */
public interface IGVDao extends IGenericDao<GlobalVariable, String>{
	
	public void batchDeleteById(String dSQL[]);
	
	public List<GlobalVariable> queryAll(GlobalVariable gv) ;
}
