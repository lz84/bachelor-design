/**
 * 
 */
package cn.hypersoft.demo.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.hypersoft.demo.service.SecurityUserService;
import cn.hypersoft.demo.service.UserService;

/**
 * @author DELL
 * 
 */
@Controller
@RequestMapping("/login")
public class LoginController {

	@Autowired
	UserService userService;

	@Autowired
	SecurityUserService securityUserService;

	@RequestMapping(value = "/form", method = RequestMethod.GET)
	String input() {
		return "login";
	}

	@RequestMapping("/error")
	String error() {
		return "error";
	}
}
