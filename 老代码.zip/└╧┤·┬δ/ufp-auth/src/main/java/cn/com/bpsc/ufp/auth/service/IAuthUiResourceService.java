package cn.com.bpsc.ufp.auth.service;

import java.util.List;


import cn.com.bpsc.ufp.auth.domain.AuthUiResource;
import cn.com.bpsc.ufp.auth.domain.Role;
import cn.com.bpsc.ufp.auth.vo.AuthUiResourceVo;

public interface IAuthUiResourceService {
	
	public void add(AuthUiResource resource);
	
	public void update(AuthUiResource resource);
	
	public void addOrUpdate(AuthUiResource resource);
	
	public void delete(AuthUiResource resource);
	
	public void deleteById(String id);
	
	public List<AuthUiResource> findAll();
	
	public AuthUiResourceVo findById(String id);
	
	public List<AuthUiResourceVo> findByFuncId(String funcId);
	
	public List<AuthUiResourceVo> findByExample(AuthUiResourceVo aur);
	
	public List<AuthUiResourceVo> findByFuncUrlAndRoleIds(String funcUrl);
	
	public void batchDelete(String info);
	
}
