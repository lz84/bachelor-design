package cn.hypersoft.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import cn.hypersoft.demo.service.MessageService;

@Configuration
@ComponentScan
public class Run {
	private static ApplicationContext context;

	public static void main(String[] args) {
		context = new AnnotationConfigApplicationContext(Run.class);
		MessageService service = context.getBean(MessageService.class);
		service.printMessage();
	}
}
