package cn.com.bpsc.ufp.bpm.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.impl.bpmn.behavior.UserTaskActivityBehavior;
import org.activiti.engine.impl.form.FormPropertyHandler;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.activiti.engine.impl.pvm.PvmProcessDefinition;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
import org.activiti.engine.impl.pvm.process.TransitionImpl;
import org.activiti.engine.impl.task.TaskDefinition;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.runtime.ProcessInstanceQuery;
import org.activiti.engine.task.Comment;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Service;
import cn.com.bpsc.ufp.auth.common.AuthConstant;
import cn.com.bpsc.ufp.auth.domain.Role;
import cn.com.bpsc.ufp.bpm.common.Constant;
import cn.com.bpsc.ufp.bpm.dao.IBpmTaskReviewDao;
import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.bpm.domain.BpStartedEvent;
import cn.com.bpsc.ufp.bpm.domain.BpmTaskReview;
import cn.com.bpsc.ufp.bpm.domain.ReviewResult;
import cn.com.bpsc.ufp.bpm.domain.TaskCompletedEvent;
import cn.com.bpsc.ufp.bpm.domain.TaskEx;
import cn.com.bpsc.ufp.bpm.domain.TaskType;
import cn.com.bpsc.ufp.bpm.service.IBpmCandidateService;
import cn.com.bpsc.ufp.bpm.service.IBpmEngineService;
import cn.com.bpsc.ufp.bpm.service.IBpmRejectService;
import cn.com.bpsc.ufp.bpm.service.IBpmRepositoryService;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeTaskService;
import cn.com.bpsc.ufp.bpm.vo.PiStatus;
import cn.com.bpsc.ufp.context.service.IVLService;
import cn.com.bpsc.ufp.org.domain.User;
import cn.com.bpsc.ufp.org.service.IUserService;

/**
 * 
 * @author zhangtao
 * 
 */
@Service
public class BpmRuntimeServiceImpl implements IBpmRuntimeService,
		ApplicationEventPublisherAware {
	@Autowired
	private IBpmEngineService bpmEngineService;

	@Autowired
	private IBpmTaskReviewDao dao;

	@Autowired
	private ApplicationEventPublisher publisher;

	@Autowired
	private RuntimeService runtimeService;
	@Autowired
	private TaskService taskService;
	@Autowired
	private IBpmRepositoryService bpmRepositoryService;

	@Autowired
	private IVLService vlService;

	@Autowired
	private IBpmRuntimeTaskService bpmTaskService;

	@Autowired
	private IBpmTaskReviewDao bpmTaskReviewDao;

	@Autowired
	private HistoryService historyService;

	@Autowired
	private IdentityService identityService;

	@Autowired
	private RepositoryService repositoryService;

	@Autowired
	private IBpmRejectService rejectService;
	@Autowired
	private IUserService userService;
	@Autowired
	private IBpmCandidateService bpmCandidateService;

	private Log log = LogFactory.getLog(this.getClass());

	private User user;

	@Override
	public ProcessInstance startProcessInstanceByKey(String pdkey,
			BaseBpDataEx bpDataEx) {
		Map<String, Object> pv = new HashMap<String, Object>();
		// 将此处改造，不再将bpDataEx对象存入数据库
		// pv.put(Constant.BPM_BP_DATA_EX_KEY, bpDataEx);
		user = (User) vlService.getSessionAttribute(AuthConstant.LOGIN_USER);
		bpDataEx.setStartUserId(user.getId());
		bpDataEx.setStartUserName(user.getUsername());
		bpDataEx.setStartCompanyId(user.getOwnerOrg().getCompanyId());
		bpDataEx.setStartCompanyName(user.getOwnerOrg().getCompanyName());
		bpDataEx.setStartCompanyShortName(user.getOwnerOrg()
				.getCompanyShortName());
		// 将bpDataEx的所有属性存入
		addToGvMap(bpDataEx, pv);
		Map<String, Object> businessExtMap = bpDataEx.getBusinessExtMap();
		addBunissMapToGv(businessExtMap, pv);
		identityService.setAuthenticatedUserId(user.getId());
		ProcessInstance pi = runtimeService.startProcessInstanceByKey(pdkey,
				bpDataEx.getDomainId(), pv);
		bpDataEx.setPiId(pi.getId());
		BpStartedEvent event = new BpStartedEvent(bpDataEx);
		this.publisher.publishEvent(event);
		return pi;
	}

	private Map<String, Object> copyGvInfoToBunissMap(Map<String, Object> pv,
			BaseBpDataEx bpDataEx) {
		Map<String, Object> businessExtMap = new HashMap<String, Object>();
		try {
			Map map = PropertyUtils.describe(bpDataEx);
			for (Object gvkeyObj : pv.keySet()) {
				if (!(gvkeyObj instanceof String)) {
					continue;
				}
				String key = gvkeyObj.toString();
				if (!map.keySet().contains(gvkeyObj)) {
					businessExtMap.put(key, pv.get(key));
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return businessExtMap;

	}

	private void addBunissMapToGv(Map<String, Object> businessExtMap,
			Map<String, Object> pv) {
		for (Object keyObj : businessExtMap.keySet()) {
			if (!(keyObj instanceof String)) {
				continue;
			}
			String key = keyObj.toString();
			pv.put(key, businessExtMap.get(key));
		}
	}

	private void addToGvMap(Object bpDataEx, Map<String, Object> pv) {
		try {
			Map map = PropertyUtils.describe(bpDataEx);
			for (Object keyObj : map.keySet()) {
				if (!(keyObj instanceof String)) {
					continue;
				}
				String key = keyObj.toString();
				if (key.equals("taskEx")) {
					continue;
				}
				if (key.equals("class")) {
					continue;
				}
				Object valueObj = map.get(key);

				if (valueObj instanceof Map) {
					continue;
				}
				pv.put(key, valueObj);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public List<User> getTaskCandidateUser() {
		BaseBpDataEx bpinfoEx = (BaseBpDataEx) vlService
				.getRequestAttribute(Constant.BPM_BP_DATA_EX_KEY);

		List<User> userList = bpmTaskService.getUsersByTaskId(bpinfoEx
				.getTaskEx().getTask().getId());
		return userList;
	}

	@Override
	public <T extends BaseBpDataEx> void complete(String taskId, T bpDataEx) {
		completeTask(bpDataEx);
	}

	@Override
	public <T extends BaseBpDataEx> void completeAndClaim(String taskId,
			String userId, T bpDataEx) {
		taskService.claim(taskId, userId);
		complete(taskId, bpDataEx);
	}

	@Override
	public void complete() {
		BaseBpDataEx bpDataEx = (BaseBpDataEx) vlService
				.getRequestAttribute(Constant.BPM_BP_DATA_EX_KEY);
		// 流转节点
		completeTask(bpDataEx);
	}

	private <T extends BaseBpDataEx> void completeTask(T bpDataEx) {
		User user = (User) vlService
				.getSessionAttribute(AuthConstant.LOGIN_USER);
		taskService.setAssignee(bpDataEx.getTaskEx().getTask().getId(),
				user.getId());
		Map<String, Object> gvMap = getGvMap(bpDataEx.getPiId());
		// gvMap.put(Constant.BPM_BP_DATA_EX_KEY, bpDataEx);
		addToGvMap(bpDataEx, gvMap);
		addBunissMapToGv(bpDataEx.getBusinessExtMap(), gvMap);
		taskService.complete(bpDataEx.getTaskEx().getTask().getId().toString(),
				gvMap);
		TaskCompletedEvent event = new TaskCompletedEvent(bpDataEx);
		this.publisher.publishEvent(event);
	}

	private Map<String, Object> getGvMap(String piId) {
		Map<String, Object> gvMap = runtimeService.getVariables(piId);
		return gvMap;
	}

	@Override
	public void completeAndClaim(String userId) {
		BaseBpDataEx bpDataEx = (BaseBpDataEx) vlService
				.getRequestAttribute(Constant.BPM_BP_DATA_EX_KEY);
		taskService.claim(bpDataEx.getTaskEx().getTask().getId(), userId);
		completeTask(bpDataEx);
	}

	@Override
	public BaseBpDataEx getBpDataEx(String piId) {
		BaseBpDataEx bpDataEx = (BaseBpDataEx) vlService
				.getRequestAttribute(Constant.BPM_BP_DATA_EX_KEY);
		if (bpDataEx != null && bpDataEx.getPiId().equals(piId)) {
			return bpDataEx;
		}
		long count = runtimeService.createProcessInstanceQuery()
				.processInstanceId(piId).count();
		if (count == 0) {
			// 将GvMap取出，并为BaseBpDataEx对象填充对应的数据
			List<HistoricVariableInstance> variableList = historyService
					.createHistoricVariableInstanceQuery()
					.processInstanceId(piId).list();
			if (variableList == null || variableList.size() == 0)
				return null;
			if (variableList != null) {
				bpDataEx = new BaseBpDataEx();
				Map<String, Object> gvMap = new HashMap<String, Object>();
				Map<String, Object> bMap = new HashMap<String, Object>();
				for (HistoricVariableInstance hvi : variableList) {
					if (hvi.getValue() != null)
						gvMap.put(hvi.getVariableName(), hvi.getValue());
				}
				try {
					BeanUtils.copyProperties(bpDataEx, gvMap);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}
				bMap = copyGvInfoToBunissMap(gvMap, bpDataEx);
				bpDataEx.setBusinessExtMap(bMap);
				vlService.setRequestAttribute(Constant.BPM_BP_DATA_EX_KEY,
						bpDataEx);
				return bpDataEx;
			} else {
				return null;
			}
		} else {
			// 当前版本BpDataEx不在序列化到数据库中。将通过下面方式返回BpDataEx。
			bpDataEx = new BaseBpDataEx();
			Map<String, Object> gvMap = runtimeService.getVariables(piId);
			Map<String, Object> bMap = new HashMap<String, Object>();
			try {
				BeanUtils.copyProperties(bpDataEx, gvMap);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
			bMap = copyGvInfoToBunissMap(gvMap, bpDataEx);
			bpDataEx.setBusinessExtMap(bMap);
			TaskEx taskEx = bpmTaskService.getActiveTask(piId);
			bpDataEx.setTaskEx(taskEx);
			vlService
					.setRequestAttribute(Constant.BPM_BP_DATA_EX_KEY, bpDataEx);
			return bpDataEx;
		}
	}

	/**
	 * 根据bizkey获取子流程的实例
	 * 
	 * @param bizKey
	 * @return
	 */
	public List<ProcessInstance> getSubProcessByBizKey(String bizKey) {

		return null;
	}

	/**
	 * 根据piid获取该流程的全部子活动流程实例
	 * 
	 * @param piid
	 * @return
	 */
	public List<ProcessInstance> getSubProcessByPiid(String piid) {
		List<ProcessInstance> subProcessList = new ArrayList<ProcessInstance>();
		subProcessList = runtimeService.createProcessInstanceQuery()
				.superProcessInstanceId(piid).list();
		return subProcessList;
	}

	@Override
	public void setAssignee(String taskId, String userId) {
		taskService.setAssignee(taskId, userId);
	}

	@Override
	public void deleteProcessInstance(String processInstanceId,
			String deleteReason) {

		runtimeService.deleteProcessInstance(processInstanceId, deleteReason);
		historyService.deleteHistoricProcessInstance(processInstanceId);
	}

	@Override
	public void addCandidateUser(String taskId, List userId, List groupId) {
		if (userId != null && userId.size() > 0) {
			for (Object object : userId) {
				taskService.addCandidateUser(taskId, (String) object);
			}

		}
		if (groupId != null && groupId.size() > 0) {
			for (Object object2 : groupId) {
				taskService.addCandidateGroup(taskId, (String) object2);
			}
		}
	}

	@Override
	public BaseBpDataEx getBpDataExByBizKey(String bizKey) {
		BaseBpDataEx bpDataEx = (BaseBpDataEx) vlService
				.getRequestAttribute(Constant.BPM_BP_DATA_EX_KEY);
		if (bpDataEx != null && bpDataEx.getDomainId().equals(bizKey)) {
			return bpDataEx;
		}
		String piId = null;
		ProcessInstance pi = runtimeService.createProcessInstanceQuery()
				.processInstanceBusinessKey(bizKey).singleResult();
		if (pi == null) {
			HistoricProcessInstance hpi = historyService
					.createHistoricProcessInstanceQuery()
					.processInstanceBusinessKey(bizKey).singleResult();
			if (hpi == null) {
				return null;
			} else {
				piId = hpi.getId();
			}
		} else {
			piId = pi.getProcessInstanceId();
		}
		bpDataEx = getBpDataEx(piId);

		return bpDataEx;
	}

	public List<User> getTaskCandidateUserByBizKey(String bizKey) {
		BaseBpDataEx bpDataEx = this.getBpDataExByBizKey(bizKey);
		if (bpDataEx != null) {
			return bpmTaskService.getUsersByTaskId(bpDataEx.getTaskEx()
					.getTask().getId());
		} else {
			return null;
		}
	}

	@Override
	public void setApplicationEventPublisher(
			ApplicationEventPublisher applicationEventPublisher) {
		this.publisher = applicationEventPublisher;
	}

	@Override
	public Comment getTaskComment(String taskId) {
		return taskService.getTaskComments(taskId).get(0);
	}

	@Override
	public List<TaskEx> getUnFinishedTaskByPiid(String piid) {
		List<Task> taskList = taskService.createTaskQuery()
				.processInstanceId(piid).list();
		List<TaskEx> taskExList = new ArrayList<TaskEx>();
		for (Task task : taskList) {
			TaskEx taskEx = new TaskEx();
			taskExList.add(taskEx);
			String formKey = bpmTaskService.getTaskURL(task);
			taskEx.setFormKey(formKey);
			taskEx.setTask(task);
		}
		return taskExList;
	}

	@Override
	public BaseBpDataEx getBpDataExByTaskId(String taskId) {
		TaskEx task = bpmTaskService.getTask(taskId);
		BaseBpDataEx bpDataEx = getBpDataEx(task.getTask()
				.getProcessInstanceId());
		return bpDataEx;
	}

	@Override
	public List<User> getTaskCandidateUserByDefKey(String piId,
			String taskDefKey) {
		String pdId = runtimeService.createProcessInstanceQuery()
				.processInstanceId(piId).singleResult()
				.getProcessDefinitionId();
		TaskDefinition taskDef = bpmTaskService.getTaskDefition(pdId,
				taskDefKey);
		List<User> userList = bpmTaskService.getUserByTaskDefinition(taskDef,
				piId);
		return userList;
	}

	@Override
	public List<User> getTaskCandidateUserByDefKey2(String piId,
			String taskDefKey) {
		String pdId = runtimeService.createProcessInstanceQuery()
				.processInstanceId(piId).singleResult()
				.getProcessDefinitionId();
		TaskDefinition taskDef = bpmTaskService.getTaskDefition(pdId,
				taskDefKey);
		List<User> userList = bpmTaskService.getUserByTaskDefinition2(taskDef,
				piId);
		return userList;
	}

	@Override
	public <T extends BaseBpDataEx> BpmTaskReview completeReview(String taskId,
			String title, String content, String comment,
			String fallBackReason, String result, String assigneer, T bpDataEx) {
		user = (User) vlService.getSessionAttribute(AuthConstant.LOGIN_USER);
		if (bpDataEx != null) {
			vlService
					.setRequestAttribute(Constant.BPM_BP_DATA_EX_KEY, bpDataEx);
		}
		List<String> assigneerList = new ArrayList<String>();
		Map<String, String> assigneerMap = new HashMap<String, String>();
		if (!StringUtils.isEmpty(assigneer)) {
			String[] assigneerStr = assigneer.split(";");
			for (String aig : assigneerStr) {
				if (!StringUtils.isEmpty(aig)) {
					assigneerMap.put(aig, aig);
				}
			}
		}

		TaskDefinition ActiveTaskDef = bpmTaskService.getTaskDefition(bpDataEx
				.getTaskEx().getTask().getProcessDefinitionId(), bpDataEx
				.getTaskEx().getTask().getTaskDefinitionKey());

		// Boolean isGroupJoint = false;
		Boolean isJointTask = false;
		try {
			// 获取节点出线的终点
			Map<String, Object> bpDataExMap = PropertyUtils.describe(bpDataEx);
			String outGoingTransValue = (String) bpDataExMap.get("NEXT_STEP");
			ActivityImpl actImpl = bpmEngineService.getOutGoingActivityImpl(
					bpDataEx.getDomainId(), outGoingTransValue);
			/*********** 判断流转的终点节点是否是会签节点 ***************/
			if (actImpl != null) {
				isJointTask = bpmEngineService
						.isJointTask((TaskDefinition) actImpl
								.getProperty("taskDefinition"));
			}
			// 判断节点出线终点的节点是否是会签节点
			if (isJointTask) {
				String MIAssigneeListName = bpmEngineService
						.getMIAssigneeListName(actImpl);
				List<String> paramAssigneerList = new ArrayList<String>();
				// 此处修改扩展属性的存储方式
				paramAssigneerList = (List) bpDataEx.getBusinessExtMap().get(
						MIAssigneeListName);
				if (StringUtils.isEmpty(assigneer)
						&& paramAssigneerList != null
						&& paramAssigneerList.size() > 0) {
					assigneerList.addAll(paramAssigneerList);
				} else if (!StringUtils.isEmpty(assigneer)) {
					assigneerList.addAll(assigneerMap.keySet());
				}
				Map<String, Object> businessExtMap = bpDataEx
						.getBusinessExtMap();
				// 此处修改扩展属性的存储方式
				businessExtMap.put(MIAssigneeListName, assigneerList);
				// 获取流程的通用变量
				Map<String, Object> GvMap = new HashMap<String, Object>();
				// 将业务扩展变量转存入流程通用变量
				addBunissMapToGv(businessExtMap, GvMap);
				// 将流程数据封装对象，转存入流程通用变量
				addToGvMap(bpDataEx, GvMap);
				runtimeService.setVariables(bpDataEx.getPiId(), GvMap);
				vlService.setRequestAttribute(Constant.BPM_BP_DATA_EX_KEY,
						bpDataEx);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		// 获取该节点的前进终点对象
		Boolean isLastTask = Boolean.FALSE;
		if (bpDataEx.getDomainId() != null) {
			List<TaskDefinition> lastTaskList = bpmTaskService
					.getLastTaskDef(bpDataEx.getDomainId());
			for (TaskDefinition lastTaskdef : lastTaskList) {
				if (lastTaskdef.getKey().equals(
						bpDataEx.getTaskEx().getTask().getTaskDefinitionKey())) {
					String keyName = lastTaskdef.getKey();
					isLastTask = Boolean.TRUE;
				}
			}
		}
		// 此处加入对操作节点的代办人属性的获取
		String taskAssignType = "";
		try {
			taskAssignType = getTaskAssignType(ActiveTaskDef);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		// 保存审核信息，此处是第一保存
		BpmTaskReview taskReview = saveTaskReview(bpDataEx, title, content,
				comment, fallBackReason, result, taskAssignType);
		ReviewResult reviewResult = null;
		for (ReviewResult rr : ReviewResult.values()) {
			if (rr.getName().equals(result)) {
				reviewResult = rr;
				break;
			}
		}
		if (reviewResult != null) {
			// || reviewResult.equals(ReviewResult.unpass)
			if (reviewResult.equals(ReviewResult.reject)) {
				// 退回到初始节点
				rejectService.reject(taskId, bpDataEx);
				isLastTask = Boolean.FALSE;
			} else {
				// 流转节点

				complete(taskId, bpDataEx);
				if (reviewResult.equals(ReviewResult.reject)
						|| reviewResult.equals(ReviewResult.unpass)) {
					isLastTask = Boolean.FALSE;
				}
			}
		}
		TaskEx task = null;
		TaskType type = null;
		if (!isLastTask && !isJointTask) {
			task = bpmTaskService.getActiveTask(bpDataEx.getPiId());
			type = bpmTaskService.getTaskType(task.getTask().getId());
			if (type == null) {
				if (assigneerMap.keySet() != null
						&& assigneerMap.keySet().size() > 0) {
					List<IdentityLink> candidateUserLink = taskService
							.getIdentityLinksForTask(task.getTask().getId());
					for (IdentityLink idLink : candidateUserLink) {
						if (idLink.getUserId() == null
								&& idLink.getGroupId() != null) {
							taskService.deleteCandidateUser(task.getTask()
									.getId(), idLink.getGroupId());
							continue;
						}
						if (!StringUtils.isEmpty(assigneerMap.get(idLink
								.getUserId()))) {
							assigneerMap.remove(idLink.getUserId());
							continue;
						} else {
							taskService.deleteCandidateUser(task.getTask()
									.getId(), idLink.getUserId());
						}
					}
					for (String userId : assigneerMap.keySet()) {
						taskService.addCandidateUser(task.getTask().getId(),
								userId);
					}
				}
			}
		}
		if (task != null) {
			TaskDefinition TaskDef = bpmTaskService.getTaskDefition(task
					.getTask().getProcessDefinitionId(), task.getTask()
					.getTaskDefinitionKey());
			try {
				taskAssignType = getTaskAssignType(TaskDef);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
			taskReview.setReviewTaskAssignType(taskAssignType);
			return updateTaskReview(taskReview, task.getTask().getId());
		} else {
			return taskReview;
		}
	}

	private BpmTaskReview updateTaskReview(BpmTaskReview taskReview,
			String targetTaskId) {
		TaskEx task = bpmTaskService.getTask(targetTaskId);
		taskReview.setTargetTaskId(task.getTask().getId());
		taskReview.setTargetTaskDefKey(task.getTask().getTaskDefinitionKey());
		taskReview.setTargetTaskName(task.getTask().getName());
		bpmTaskReviewDao.update(taskReview);
		return taskReview;
	}

	private BpmTaskReview saveTaskReview(BaseBpDataEx bpDataEx, String title,
			String content, String comment, String fallBackReason,
			String result, String taskAssignType) {

		// TODO
		BpmTaskReview review = new BpmTaskReview();
		User user = (User) vlService
				.getSessionAttribute(AuthConstant.LOGIN_USER);

		if (bpDataEx == null || user == null
				|| bpDataEx.getTaskEx().getTask() == null) {
			return null;
		}
		Task task = bpDataEx.getTaskEx().getTask();
		ProcessDefinition pd = bpmRepositoryService.getPdById(task
				.getProcessDefinitionId());
		if (pd == null) {
			return null;
		}
		review.setBizKey(bpDataEx.getDomainId());
		review.setExecId(task.getExecutionId());
		review.setPdId(pd.getId());
		review.setPdKey(pd.getKey());
		review.setPdName(pd.getName());
		review.setPdVersion(pd.getVersion());
		review.setPiId(task.getProcessInstanceId());
		review.setReviewComment(comment);
		review.setReviewCompanyId(user.getOwnerOrg().getCompanyId());
		review.setReviewCompanyName(user.getOwnerOrg().getCompanyName());
		review.setReviewContent(content);
		review.setReviewDate(new Date());
		review.setReviewDepartmentId(user.getOwnerOrg().getDepartmentId());
		review.setReviewDepartmentName(user.getOwnerOrg().getDepartmentName());
		review.setReviewResult(result);
		review.setReviewTaskDefKey(task.getTaskDefinitionKey());
		review.setReviewTaskId(task.getId());
		review.setReviewTaskName(task.getName());
		review.setReviewTitle(title);
		review.setReviewUserId(user.getId());
		review.setReviewUserName(user.getUsername());
		review.setReviewFallbackReasoin(fallBackReason);
		review.setReviewTaskAssignType(taskAssignType);
		if (bpDataEx.getTaskEx().getTaskType() != null) {
			review.setReviewType(String.valueOf(bpDataEx.getTaskEx()
					.getTaskType()));
		}

		bpmTaskReviewDao.save(review);
		return review;
	}

	@Override
	public List<BpmTaskReview> getTaskReviewsByTaskId(String taskId) {
		return bpmTaskReviewDao.getTaskReviewsByTaskId(taskId);
	}

	@Override
	public List<BpmTaskReview> getTaskReviewsByBizKey(String bizKey) {
		return bpmTaskReviewDao.getTaskReviewsByBizKey(bizKey);
	}

	@Override
	public void setPiVariable(String piId, String variableName,
			Object variableValue) {
		runtimeService.setVariable(piId, variableName, variableValue);
	}

	@Override
	public Object getPiVariable(String piId, String variableName) {
		Object obj = runtimeService.getVariable(piId, variableName);
		return obj;
	}

	@Override
	public Map<String, Object> getPiVariableMap(String piId) {
		return runtimeService.getVariables(piId);
	}

	@Override
	public PiStatus getPiStatusByBizKey(String bizKey) {
		ProcessInstanceQuery query = runtimeService
				.createProcessInstanceQuery();
		long count = query.processInstanceBusinessKey(bizKey).count();
		if (count > 0) {
			// 流程正在运行中
			return PiStatus.Running;
		} else {
			count = historyService.createHistoricProcessInstanceQuery()
					.finished().processInstanceBusinessKey(bizKey).count();
			if (count > 0) {
				// 流程已经结束
				return PiStatus.Finished;
			} else {
				// 没有流程信息
				return PiStatus.NotFound;
			}
		}
	}

	@Override
	public PiStatus getPiStatusByPiId(String piId) {
		ProcessInstanceQuery query = runtimeService
				.createProcessInstanceQuery();
		long count = query.processInstanceId(piId).count();
		if (count > 0) {
			// 流程正在运行中
			return PiStatus.Running;
		} else {
			count = historyService.createHistoricProcessInstanceQuery()
					.finished().processInstanceId(piId).count();
			if (count > 0) {
				// 流程已经结束
				return PiStatus.Finished;
			} else {
				// 没有流程信息
				return PiStatus.NotFound;
			}
		}
	}

	@Override
	public ProcessInstance findByPiId(String piId) {
		ProcessInstance pi = runtimeService.createProcessInstanceQuery()
				.processInstanceId(piId).singleResult();
		return pi;
	}

 	public ProcessInstance findByBizKey(String bizKey) {
		ProcessInstance pi = runtimeService.createProcessInstanceQuery()
				.processInstanceBusinessKey(bizKey).singleResult();
		return pi;
	}

	@Override
	public List<User> getHisTaskCandidateUserByDefKey(String pdid, String PiId,
			String taskDefKey) {
		TaskDefinition taskDef = bpmTaskService.getTaskDefition(pdid,
				taskDefKey);
		List<User> userList = bpmTaskService.getUserByTaskDefinition2(taskDef,
				PiId);
		return userList;
	}

	@Override
	public <T extends BaseBpDataEx> void signal(String taskId,
			String targetTaskDefKey, T bpDataEx) {
		TaskEx taskEx = bpmTaskService.getTask(taskId);
		String pdId = taskEx.getTask().getProcessDefinitionId();
		ActivityImpl sourceActivity = null;
		ActivityImpl destActivity = null;
		ProcessDefinitionEntity def = (ProcessDefinitionEntity) ((org.activiti.engine.impl.RepositoryServiceImpl) repositoryService)
				.getDeployedProcessDefinition(pdId);
		List<ActivityImpl> activitiList = def.getActivities();
		if (activitiList != null && !activitiList.isEmpty()) {
			for (ActivityImpl activityImpl : activitiList) {
				if (activityImpl.getId().equals(targetTaskDefKey)) {
					destActivity = activityImpl;
				}
				if (activityImpl.getId().equals(
						taskEx.getTask().getTaskDefinitionKey())) {
					sourceActivity = activityImpl;
				}
			}
		}
		if (destActivity == null || sourceActivity == null) {
			return;
		}
		// 清空当前节点的出线
		List<PvmTransition> outTrans = bpmEngineService
				.clearOutTransition(sourceActivity);
		// 创建新流向出线
		TransitionImpl newTrans = sourceActivity.createOutgoingTransition();
		newTrans.setDestination(destActivity);
		// 流转节点
		complete(taskId, bpDataEx);
		// 恢复出线
		bpmEngineService.restoreOutTransition(sourceActivity, outTrans);
	}

	@Override
	public List<User> getNextTaskCandidateUser(String bizKey) {
		ProcessInstance pi = findByBizKey(bizKey);
		Map<PvmTransition, ActivityImpl> actImplMap = bpmEngineService
				.getNextActivityImpl(bizKey);
		Map<PvmTransition, TaskDefinition> taskDefMap = new HashMap<PvmTransition, TaskDefinition>();
		bpmEngineService.warpTaskDefMap(actImplMap, taskDefMap);
		if (taskDefMap == null)
			return null;
		List<User> userList = new ArrayList<User>();
		List<TaskDefinition> lastTaskDefList = bpmTaskService
				.getLastTaskDef(bizKey);
		boolean isLastTask = Boolean.FALSE;
		// 返回每个transition对应的task中定义的候选人
		for (TaskDefinition taskDef : taskDefMap.values()) {
			userList.addAll(bpmTaskService.getUserByTaskDefinition2(taskDef,
					pi.getProcessInstanceId()));
		}
		return userList;
	}

	@Override
	public List<User> getNextTaskCandidateUser(String bizKey,
			String outGoingTransValue, BaseBpDataEx bpDataEx) {
		// 判断节点是否是会签节点，是会签节点，则将该节点的流程变量中的
		// 获取流程的流程变量
		ProcessInstance pi = findByBizKey(bizKey);
		if (outGoingTransValue == null || outGoingTransValue.isEmpty())
			return getNextTaskCandidateUser(bizKey);
		// 获取符合条件的出线终点对象
		ActivityImpl outGoingActivityImpl = bpmEngineService
				.getOutGoingActivityImpl(bizKey, outGoingTransValue);
		TaskDefinition outGoingTask = null;
		if (outGoingActivityImpl == null)
			return null;
		outGoingTask = (TaskDefinition) outGoingActivityImpl
				.getProperty("taskDefinition");
		// 判断节点是否是会签节点
		Boolean jointTask = false;
		Boolean autoSetAssigneer = false;
		List<User> userList = new ArrayList<User>();
		List<String> tempUserList = new ArrayList<String>();
		try {
			jointTask = bpmEngineService.isJointTask(outGoingTask);
			autoSetAssigneer = bpmEngineService
					.isAutoSetAssignments(outGoingTask);
			if (autoSetAssigneer)
				return null;
			if (jointTask) {
				String MIAssigneeListName = bpmEngineService
						.getMIAssigneeListName(outGoingActivityImpl);
				if (!StringUtils.isEmpty(MIAssigneeListName))
					tempUserList = (List<String>) bpDataEx.getBusinessExtMap()
							.get(MIAssigneeListName);
				if (tempUserList != null && tempUserList.size() > 0) {
					for (String userId : tempUserList) {
						userList.add(userService.findById(userId));
					}
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		if (userList != null && userList.size() == 0)
			userList = bpmTaskService.getUserByTaskDefinition2(outGoingTask,
					pi.getProcessInstanceId());
		return userList;
	}

	@Override
	public Map<PvmTransition, TaskDefinition> getNextTaskDefinition(
			String bizKey) {
		Map<PvmTransition, ActivityImpl> actImplMap = bpmEngineService
				.getNextActivityImpl(bizKey);
		Map<PvmTransition, TaskDefinition> taskDefMap = new HashMap<PvmTransition, TaskDefinition>();
		bpmEngineService.warpTaskDefMap(actImplMap, taskDefMap);
		return taskDefMap;
	}

	/**
	 * 私有方法:该方法负责更新CurrentOperator流程参与者数据 开发者：张涛 开发时间：2013-11-29
	 * 
	 */
	private List<String> refreshCurrentOperator(String userId, List copList) {
		List<String> roleList = bpmCandidateService.getGroupIdByUser(userId);
		if (roleList != null && copList != null) {
			for (int i = copList.size() - 1; i > 0; i--) {
				if (roleList.contains(copList.get(i)))
					copList.remove(i);
			}
		}
		return roleList;
	}

	/**
	 * 私有方法：该方法返回节点的代办使用人属性
	 * 
	 * @param taskDef
	 * @return
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 */
	private String getTaskAssignType(TaskDefinition taskDef)
			throws IllegalAccessException, InvocationTargetException,
			NoSuchMethodException {
		String taskAssignType = "";
		Object taskFormHandler = taskDef.getTaskFormHandler();
		Map porpMap = PropertyUtils.describe(taskFormHandler);
		List<FormPropertyHandler> formPropertyHandlers = (List<FormPropertyHandler>) porpMap
				.get("formPropertyHandlers");
		if (formPropertyHandlers == null || formPropertyHandlers.size() == 0)
			return null;
		for (FormPropertyHandler formPropertyHandler : formPropertyHandlers) {
			if ("task_assign_type".equals(formPropertyHandler.getId())) {
				return formPropertyHandler.getName();
			}
		}
		return null;
	}


	@Override
	public void finishProcess(String assigner) {
		// TODO Auto-generated method stub
		
	}

}
