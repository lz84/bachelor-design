prompt Importing table T_UFP_AUTH_ROLE_USER...
set feedback off
set define off
insert into T_UFP_AUTH_ROLE_USER (ID, USER_ID, ROLE_ID)
values ('fafa39a541c5f39f0141c5f45f2e0000', 'guest', '8a1c52923f84efea013f84f36ae2003b');

insert into T_UFP_AUTH_ROLE_USER (ID, USER_ID, ROLE_ID)
values ('3', 'superadmin', '8a1c53cc3f5a637f013f5a67e4e0001e');

prompt Done.
