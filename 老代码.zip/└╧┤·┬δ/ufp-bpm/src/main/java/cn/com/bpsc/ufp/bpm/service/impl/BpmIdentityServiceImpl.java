package cn.com.bpsc.ufp.bpm.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.task.TaskDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.bpm.service.IBpmEngineService;
import cn.com.bpsc.ufp.bpm.service.IBpmHistoryTaskService;
import cn.com.bpsc.ufp.bpm.service.IBpmIdentityService;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeTaskService;
import cn.com.bpsc.ufp.org.domain.User;

@Service
public class BpmIdentityServiceImpl implements IBpmIdentityService{
@Autowired
private IBpmRuntimeService bpmRuntimeService;
@Autowired
private IBpmEngineService bpmEngineService;
@Autowired
private IBpmRuntimeTaskService bpmRuntimeTaskService;
@Autowired
private IBpmHistoryTaskService bpmHistoryTaskService;
	
	@Override
	public List<User> getNextTaskCandidateUser(String bizKey) {
		ProcessInstance pi = bpmRuntimeService.findByBizKey(bizKey);
		Map<PvmTransition, ActivityImpl> actImplMap = bpmEngineService.getNextActivityImpl(bizKey);
		Map<PvmTransition, TaskDefinition> taskDefMap = new HashMap<PvmTransition, TaskDefinition>();
		bpmEngineService.warpTaskDefMap(actImplMap, taskDefMap);
		if (taskDefMap == null)
			return null;
		List<User> userList = new ArrayList<User>();
		List<TaskDefinition> lastTaskDefList = bpmRuntimeTaskService
				.getLastTaskDef(bizKey);
		boolean isLastTask = Boolean.FALSE;
		// 返回每个transition对应的task中定义的候选人
		for (TaskDefinition taskDef : taskDefMap.values()) {
			userList.addAll(bpmRuntimeTaskService.getUserByTaskDefinition2(taskDef,
					pi.getProcessInstanceId()));
		}
		return userList;
	}

	@Override
	public List<User> getUsersByTaskId(String taskId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getPreviousTaskReviewUser(String exid) {
		//此方法用于将节点的历史操作数据取出
		List<HistoricTaskInstance> hist=bpmHistoryTaskService.getProcessCompleteHistoric(exid);
		if(hist==null && hist.size()<=0)
			return null;
		HistoricTaskInstance previousTask=previousTask=hist.get(0);
		//previousTask.get
		return null;
	}

	@Override
	public List<User> getLastTaskAssigneerByTaskDefKey(String taskDefKey) {
		// TODO Auto-generated method stub
		return null;
	}

}
