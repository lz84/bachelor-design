package cn.com.bpsc.ufp.bpm.service;

import java.util.Set;

import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.org.domain.User;

public interface IGroupExpResolveService {

	public Set<User> resolve(String groupOrgExp, BaseBpDataEx bpDataEx);
	
	public String resolveGroupExp(String groupExp, BaseBpDataEx bpDataEx);
	
	public String resolveGroupExp(String groupExp, String piId);
}
