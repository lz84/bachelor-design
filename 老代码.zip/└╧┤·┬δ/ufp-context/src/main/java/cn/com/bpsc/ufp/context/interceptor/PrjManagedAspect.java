package cn.com.bpsc.ufp.context.interceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;

public abstract class PrjManagedAspect extends ManageAspect {
  
	@Around("!execution(public * cn.com.bpsc.ufp.**.**..**.*(..)) and execution(public * cn.com.bpsc.**.**.biz..*Biz*.*(..)) or !execution(public * cn.com.bpsc.**.**.**..**.*(..)) and execution(public * cn.com.bpsc.**.**.dao..*Dao*.*(..))")
	  public Object intercept(ProceedingJoinPoint pjp) throws Throwable{
			
		return doIntercept(pjp);
	}
	 
}