package cn.com.bpsc.ufp.context.interceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public abstract class AllManagedBizServiceAspect extends ManageAspect {
  
	@Around("execution(public * cn.com.bpsc.**.**.biz..*Biz*.*(..)) or execution(public * cn.com.bpsc.**.**.service..*Service*.*(..))")
	  public Object intercept(ProceedingJoinPoint pjp) throws Throwable{

		return doIntercept(pjp);
	}
}
