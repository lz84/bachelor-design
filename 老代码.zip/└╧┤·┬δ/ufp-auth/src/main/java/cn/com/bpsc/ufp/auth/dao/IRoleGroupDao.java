/*
 * @(#)IRoleDao.java	Mar 18, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.auth.dao;

import java.util.List;

import cn.com.bpsc.ufp.auth.domain.RoleGroup;
import cn.com.bpsc.ufp.dao.IGenericDao;


public interface IRoleGroupDao extends IGenericDao<RoleGroup, String>{
	
	public List<RoleGroup> findAllRoleInfo();
	
	public RoleGroup findByName(String roleName);
	
	public List<RoleGroup> findChildren(String parentModuleName) ;
}
