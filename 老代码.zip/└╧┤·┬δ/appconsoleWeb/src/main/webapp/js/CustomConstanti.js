/** 北京电力公司机构ID **/
var ORG_HEIGHT_ID = "0600000000";
/** 查询全部机构 **/
var SEARCH_ALL_ORG = "0";
/** 查询flag设置为显示机构 **/
var SEARCH_SHOW_ORG = "1";