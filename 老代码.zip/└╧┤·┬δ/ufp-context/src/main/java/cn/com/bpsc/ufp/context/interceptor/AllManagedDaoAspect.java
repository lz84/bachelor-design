package cn.com.bpsc.ufp.context.interceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public abstract class AllManagedDaoAspect extends ManageAspect {
  
	@Around("execution(public * cn.com.bpsc.**.**.dao..*Dao*.*(..))")
	  public Object intercept(ProceedingJoinPoint pjp) throws Throwable{
		 
		return doIntercept(pjp);
	}
}
