package cn.com.bpsc.ufp.auth.dao.impl;

import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.auth.dao.IStatisticControllerDao;
import cn.com.bpsc.ufp.auth.domain.StatisticController;
import cn.com.bpsc.ufp.dao.impl.GenericDaoImpl;

@Service
public class StatisticControllerDaoImpl  extends GenericDaoImpl<StatisticController, String> implements IStatisticControllerDao{

}
