prompt Importing table T_UFP_AUTH_ROLE_GROUP...
set feedback off
set define off
insert into T_UFP_AUTH_ROLE_GROUP (ID, NAME, DESCRIPTION, TYPE, FLAG, PARENT_ID)
values ('fafa39a541c5619d0141c563b9940000', 'authRoleGroup', '��֤��ɫ��', null, '1', null);

prompt Done.
