package cn.com.bpsc.ufp.stat.domain;

public class FunctionAccessLog {

}
