package cn.com.bpsc.ufp.context.interceptor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public abstract class PlatManagedAspect extends ManageAspect {
  
	@Around("execution(public * cn.com.bpsc.ufp.**.dao..*Dao*.*(..)) or execution(public * cn.com.bpsc.ufp.**.service..*Service*.*(..))")
	  public Object intercept(ProceedingJoinPoint pjp) throws Throwable{
		 
		return doIntercept(pjp);
	}
}
