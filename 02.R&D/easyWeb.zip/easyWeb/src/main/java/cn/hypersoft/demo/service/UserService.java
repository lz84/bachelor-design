/**
 * 
 */
package cn.hypersoft.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.hypersoft.demo.dao.UserDao;
import cn.hypersoft.demo.entities.User;

/**
 * @author DELL
 * 
 */
@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	public Iterable<User> findAll() {
		return userDao.findAll();
	}

	public User findByLoginId(String lastName) {
		return userDao.findByLoginId(lastName);
	}

	public User findById(long id) {
		return userDao.findById(id);
	}

	@Transactional
	public void deleteUser(long id) {
		userDao.delete(id);
	}
}
