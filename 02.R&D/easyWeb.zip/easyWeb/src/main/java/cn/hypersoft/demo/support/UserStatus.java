package cn.hypersoft.demo.support;

public enum UserStatus {

	NORMAL("0", "����"), INVITE("1", "����"), EXPIRE("2", "����"), LOCKED("3", "����");
	private String value;
	private String text;

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text
	 *            the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

	private UserStatus(String value, String text) {
		this.value = value;
		this.text = text;
	}

	/**
	 * ͨ��value��ȡenmu����
	 * 
	 * @param value
	 * @return
	 */
	public static UserStatus get(String value) {
		for (UserStatus dot : UserStatus.values()) {
			if (value.equals(dot.getValue())) {
				return dot;
			}
		}
		throw new IllegalArgumentException(
				"error:Can't get enum with this oridal.");
	}
}
