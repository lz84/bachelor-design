/**
 * 
 */
package cn.hypersoft.demo.entities;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * @author DELL
 * 
 */
@Entity
@Table(name = "users")
public class User {

	@Id
	@Column(name = "id")
	private long id;
	/** �û��� **/
	@Column(name = "user_name")
	private String userName;
	/** ��½�˺� **/
	@Column(name = "login_id")
	private String loginId;
	/** �û�״̬ @see cn.hypersoft.demo.support.UserStatus **/
	@Column(name = "user_status")
	private String userStatus;
	/** ��Ȩʹ�ò�Ʒ�汾id **/
	@Column(name = "product_type_id")
	private Integer productTypeId;
	/** ��Ȩʹ�ò�Ʒ�汾 **/
	@Column(name = "product_type")
	private String productType;
	/** ��ͨ���� **/
	@Column(name = "open_date")
	private Date openDate;
	/** �������� **/
	@Column(name = "open_cycle")
	private Integer openCycle;
	/** �������� **/
	@Column(name = "invite_mail")
	private String inviteEmail;
	/** �������� **/
	@Column(name = "expire_date")
	private Date expireDate;
	/** �������� **/
	@Column(name = "create_date")
	private Date createDate;
	/** �������� **/
	@Column(name = "invite_date")
	private Date inviteDate;
	/** ����MD5�� **/
	@Column(name = "password")
	private String password;
	/** �˺����� **/
	@Column(name = "mode")
	private Integer mode;

	@ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
	@JoinTable(name = "user_group", joinColumns = { @JoinColumn(name = "user_id", referencedColumnName = "id") }, inverseJoinColumns = { @JoinColumn(name = "group_id", referencedColumnName = "id") })
	private List<Group> userGroups;

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the loginId
	 */
	public String getLoginId() {
		return loginId;
	}

	/**
	 * @param loginId
	 *            the loginId to set
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	/**
	 * @return the userStatus
	 */
	public String getUserStatus() {
		return userStatus;
	}

	/**
	 * @param userStatus
	 *            the userStatus to set
	 */
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	/**
	 * @return the productTypeId
	 */
	public Integer getProductTypeId() {
		return productTypeId;
	}

	/**
	 * @param productTypeId
	 *            the productTypeId to set
	 */
	public void setProductTypeId(Integer productTypeId) {
		this.productTypeId = productTypeId;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType
	 *            the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the openDate
	 */
	public Date getOpenDate() {
		return openDate;
	}

	/**
	 * @param openDate
	 *            the openDate to set
	 */
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	/**
	 * @return the openCycle
	 */
	public Integer getOpenCycle() {
		return openCycle;
	}

	/**
	 * @param openCycle
	 *            the openCycle to set
	 */
	public void setOpenCycle(Integer openCycle) {
		this.openCycle = openCycle;
	}

	/**
	 * @return the inviteEmail
	 */
	public String getInviteEmail() {
		return inviteEmail;
	}

	/**
	 * @param inviteEmail
	 *            the inviteEmail to set
	 */
	public void setInviteEmail(String inviteEmail) {
		this.inviteEmail = inviteEmail;
	}

	/**
	 * @return the expireDate
	 */
	public Date getExpireDate() {
		return expireDate;
	}

	/**
	 * @param expireDate
	 *            the expireDate to set
	 */
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate
	 *            the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the inviteDate
	 */
	public Date getInviteDate() {
		return inviteDate;
	}

	/**
	 * @param inviteDate
	 *            the inviteDate to set
	 */
	public void setInviteDate(Date inviteDate) {
		this.inviteDate = inviteDate;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the mode
	 */
	public Integer getMode() {
		return mode;
	}

	/**
	 * @param mode
	 *            the mode to set
	 */
	public void setMode(Integer mode) {
		this.mode = mode;
	}

	/**
	 * @return the userGroups //
	 */
	public List<Group> getUserGroups() {
		return userGroups;
	}

	/**
	 * @param userGroups
	 *            the userGroups to set
	 */
	public void setUserGroups(List<Group> userGroups) {
		this.userGroups = userGroups;
	}

	@Override
	public String toString() {
		return "loginId:" + loginId + ",productType:" + productType;
	}
}
