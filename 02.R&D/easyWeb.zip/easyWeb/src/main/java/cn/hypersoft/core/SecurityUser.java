/**
 * 
 */
package cn.hypersoft.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import cn.hypersoft.demo.entities.User;
import cn.hypersoft.demo.entities.Group;
import cn.hypersoft.demo.support.UserStatus;

/**
 * ��ȫ��֤�û�
 * 
 * @author sunchangqing
 */
public class SecurityUser extends User implements UserDetails {

	public SecurityUser(User user) {
		this.setId(user.getId());
		this.setLoginId(user.getLoginId());
		this.setPassword(user.getPassword());
		this.setUserGroups(user.getUserGroups());
		this.setUserStatus(user.getUserStatus());
		this.setExpireDate(user.getExpireDate());
	}

	private static final long serialVersionUID = -7544266810969509064L;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.core.userdetails.UserDetails#getAuthorities
	 * ()
	 */
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		Collection<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		List<Group> userRoles = this.getUserGroups();

		if (userRoles != null) {
			for (Group role : userRoles) {
				SimpleGrantedAuthority authority = new SimpleGrantedAuthority(
						role.getGroupName());
				authorities.add(authority);
			}
		}
		return authorities;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.core.userdetails.UserDetails#getPassword()
	 */
	@Override
	public String getPassword() {
		return super.getPassword();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.core.userdetails.UserDetails#getUsername()
	 */
	@Override
	public String getUsername() {
		return super.getLoginId();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.core.userdetails.UserDetails#isAccountNonExpired
	 * ()
	 */
	@Override
	public boolean isAccountNonExpired() {
		return !this.getUserStatus().equals(UserStatus.EXPIRE.getValue());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.core.userdetails.UserDetails#isAccountNonLocked
	 * ()
	 */
	@Override
	public boolean isAccountNonLocked() {
		return !this.getUserStatus().equals(UserStatus.LOCKED.getValue());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.userdetails.UserDetails#
	 * isCredentialsNonExpired()
	 */
	@Override
	public boolean isCredentialsNonExpired() {
		return this.getExpireDate().getTime() > System.currentTimeMillis();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.core.userdetails.UserDetails#isEnabled()
	 */
	@Override
	public boolean isEnabled() {
		return !this.getUserStatus().equals(UserStatus.NORMAL.getValue());
	}

}
