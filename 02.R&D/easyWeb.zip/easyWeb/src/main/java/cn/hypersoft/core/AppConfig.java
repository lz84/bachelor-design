package cn.hypersoft.core;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import cn.hypersoft.common.Constants;

/**
 * Ӧ������
 * 
 * @author sunchangqing
 * 
 */
@Configuration
@ComponentScan(basePackages = { Constants.ANNOTITION_APP_COMPONENT_SCAN_INCLUDES }, excludeFilters = @ComponentScan.Filter(type = FilterType.REGEX, pattern = { Constants.ANNOTITION_APP_COMPONENT_SCAN_EXCLUDES }))
@PropertySource(value = { Constants.SYS_CONFIG_FILE_APP })
public class AppConfig {

	@Autowired
	private Environment env;

	@Bean
	public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	public CacheManager cacheManager() {
		return new ConcurrentMapCacheManager();
	}

	@Bean
	public JavaMailSenderImpl javaMailSenderImpl() {
		JavaMailSenderImpl mailSenderImpl = new JavaMailSenderImpl();
		mailSenderImpl.setHost(env.getProperty(Constants.SYS_MAIL_CONFIG_HOST));
		mailSenderImpl.setPort(env.getProperty(Constants.SYS_MAIL_CONFIG_PORT,
				Integer.class));
		mailSenderImpl.setProtocol(env
				.getProperty(Constants.SYS_MAIL_CONFIG_PROTOCOL));
		mailSenderImpl.setUsername(env
				.getProperty(Constants.SYS_MAIL_CONFIG_USER_NAME));
		mailSenderImpl.setPassword(env
				.getProperty(Constants.SYS_MAIL_CONFIG_USER_PASSWORD));

		Properties javaMailProps = new Properties();
		javaMailProps.put("mail.smtp.auth", true);
		javaMailProps.put("mail.smtp.starttls.enable", true);

		mailSenderImpl.setJavaMailProperties(javaMailProps);

		return mailSenderImpl;
	}
}
