/*
 * @(#)IProjectPropertyService.java	Mar 8, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service;

import cn.com.bpsc.ufp.ps.domain.ProjectProperty;

public interface IProjectPropertyService {
	
	public void update(ProjectProperty pp);
	
	public void delete(ProjectProperty pp);
	
	public ProjectProperty get();
}
