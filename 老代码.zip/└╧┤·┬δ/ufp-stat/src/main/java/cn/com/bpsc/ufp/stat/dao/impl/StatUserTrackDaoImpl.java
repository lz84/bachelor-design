package cn.com.bpsc.ufp.stat.dao.impl;

import org.springframework.stereotype.Repository;

import cn.com.bpsc.ufp.dao.impl.GenericDaoImpl;
import cn.com.bpsc.ufp.stat.dao.IStatUserTrackDao;
import cn.com.bpsc.ufp.stat.domain.StatUserTrack;

@Repository
public class StatUserTrackDaoImpl extends GenericDaoImpl<StatUserTrack, String> implements IStatUserTrackDao {
 
}
