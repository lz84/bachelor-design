package cn.com.bpsc.ufp.ex.service;

import java.util.List;
import cn.com.bpsc.ufp.ex.domain.ExMsg;

public interface IExMsgService {
	
	public List<ExMsg> findExMsgInfo(ExMsg ex);
}
