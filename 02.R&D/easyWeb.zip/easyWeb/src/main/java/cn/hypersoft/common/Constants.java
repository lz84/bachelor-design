/**
 * 
 */
package cn.hypersoft.common;

/**
 * �뽫����ͳһ���
 * 
 * @author sunchangqing
 * 
 */
public class Constants {

	public final static String SYS_CONFIG_FILE_APP = "classpath:application.properties";
	public final static String SYS_CONFIG_FILE_DATASOURCE = "classpath:datasource.properties";
	/**
	 * datasource���
	 */
	public final static String DATA_SOURCE_DRIVER_CLASS_NAME = "mysql.jdbc.driverClassName";
	public final static String DATA_SOURCE_URL = "mysql.jdbc.url";
	public final static String DATA_SOURCE_USER_NAME = "mysql.jdbc.username";
	public final static String DATA_SOURCE_PASSWORD = "mysql.jdbc.password";
	public final static String DATA_SOURCE_SCRIPT_FILE_NAME = "db.sql";
	public final static String DATA_SOURCE_DIALECT="org.hibernate.dialect.MySQLDialect";
	public final static String DATA_SOURCE_PERSISTENCE_UNIT_NAME="zsm";

	/**
	 * Ӧ��ע���������
	 */
	public final static String ANNOTITION_PERSISTENCE_ENTITIES_PATH = "cn.hypersoft.*.entities";
	public final static String ANNOTITION_APP_COMPONENT_SCAN_INCLUDES = "cn.hypersoft";
	public final static String ANNOTITION_APP_COMPONENT_SCAN_EXCLUDES = "cn.hypersoft.*.web";
	public final static String ANNOTITION_WEB_COMPONENT_SCAN_INCLUDES = "cn.hypersoft.*.web";
	public final static String ANNOTITION_DAO_COMPONENT_SCAN_INCLUDES = "cn.hypersoft.*.dao";

	/**
	 * mail�������
	 */
	public final static String SYS_MAIL_CONFIG_HOST = "smtp.host";
	public final static String SYS_MAIL_CONFIG_PORT = "smtp.port";
	public final static String SYS_MAIL_CONFIG_PROTOCOL = "smtp.protocol";
	public final static String SYS_MAIL_CONFIG_USER_NAME = "smtp.username";
	public final static String SYS_MAIL_CONFIG_USER_PASSWORD = "smtp.password";

	/**
	 * ϵͳ�������
	 */
	public final static String APP_CHARACTER_ENCODING = "UTF-8";

}
