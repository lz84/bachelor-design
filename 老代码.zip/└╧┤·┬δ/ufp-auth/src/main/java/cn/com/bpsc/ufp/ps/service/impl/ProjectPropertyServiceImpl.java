/*
 * @(#)ProjectPropertyServiceImpl.java	Mar 8, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.ps.dao.IProjectPropertyDao;
import cn.com.bpsc.ufp.ps.domain.ProjectProperty;
import cn.com.bpsc.ufp.ps.service.IProjectPropertyService;

@Service(value="ppService")
public class ProjectPropertyServiceImpl implements IProjectPropertyService {

	@Autowired
	private IProjectPropertyDao dao = null;
	
	
	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectPropertyService#update(cn.com.bpsc.ufp.ps.domain.ProjectProperty)
	 */
	@Override
	public void update(ProjectProperty pp) {
		//dao.update(pp);
		dao.merge(pp);
	}

	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectPropertyService#findByPk(java.lang.String)
	 */
	@Override
	public ProjectProperty get() {
		List<ProjectProperty> ppList = dao.findAll();
		if(ppList.size() == 0) return null; 
		
		return ppList.get(0);
	}

	@Override
	public void delete(ProjectProperty pp) {
		 
		dao.delete(pp);
	}
	

}
