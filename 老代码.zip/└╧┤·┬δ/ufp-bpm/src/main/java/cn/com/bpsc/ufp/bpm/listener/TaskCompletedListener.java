package cn.com.bpsc.ufp.bpm.listener;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.bpm.common.Constant;
import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.bpm.domain.TaskCompletedEvent;
import cn.com.bpsc.ufp.bpm.domain.TaskEx;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeTaskService;
import cn.com.bpsc.ufp.context.service.IVLService;

@Service
public class TaskCompletedListener implements ApplicationListener<TaskCompletedEvent>{
	@Autowired
	private IVLService vlService;
	
	@Autowired
	private IBpmRuntimeService bpmRuntimeService;
	@Autowired
	private IBpmRuntimeTaskService bpmRuntimeTaskService;
	
	@Override
	public void onApplicationEvent(TaskCompletedEvent event) {
		BaseBpDataEx  bpDataEx=(BaseBpDataEx) event.getSource();
		BaseBpDataEx newBpDateEx = bpmRuntimeService.getBpDataEx(bpDataEx.getPiId());
		if(newBpDateEx!=null && newBpDateEx.getPiId()!=null){
			TaskEx taskEx = bpmRuntimeTaskService.getActiveTask(newBpDateEx.getPiId());
			newBpDateEx.setTaskEx(taskEx);
			vlService.setRequestAttribute(Constant.BPM_BP_DATA_EX_KEY, newBpDateEx);
			vlService.setRequestAttribute(Constant.BPM_TASK_COMPLETE_FLAG, Boolean.TRUE);
		}else{
			vlService.setRequestAttribute(Constant.BPM_BP_DATA_EX_KEY, null);
			vlService.setRequestAttribute(Constant.BPM_TASK_COMPLETE_FLAG, Boolean.FALSE);

		}
	}
	
}
