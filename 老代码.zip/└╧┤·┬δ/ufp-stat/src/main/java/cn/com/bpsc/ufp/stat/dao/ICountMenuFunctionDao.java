package cn.com.bpsc.ufp.stat.dao;


import java.util.List;

import cn.com.bpsc.ufp.auth.domain.StatisticController;
import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.stat.vo.CountConditionVo;

public interface ICountMenuFunctionDao extends IGenericDao<StatisticController, String>{

	public void saveInfo(StatisticController sc) ;
	
	public List countSystemRunEfficiency(CountConditionVo cc);
}
