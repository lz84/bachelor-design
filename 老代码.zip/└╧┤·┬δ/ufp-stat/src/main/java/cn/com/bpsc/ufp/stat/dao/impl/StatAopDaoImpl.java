package cn.com.bpsc.ufp.stat.dao.impl;

import org.springframework.stereotype.Repository;

import cn.com.bpsc.ufp.dao.impl.GenericDaoImpl;
import cn.com.bpsc.ufp.stat.dao.IStatAopDao;
import cn.com.bpsc.ufp.stat.domain.StatAop;

@Repository
public class StatAopDaoImpl extends GenericDaoImpl<StatAop,String> implements IStatAopDao {

	@Override
	public void batchDelete(String info) {
		if(info!=null && !"".equals(info)){
			String delInfo[] = info.split(",");
			String dSQL[] = new String[delInfo.length];
			int index = 0;
			for(String dInfo:delInfo){
				if(dInfo!=null && !"".equals(dInfo)){
					dSQL[index] = "delete from T_UFP_STAT_AOP where class_name='"+dInfo+"'";
					index++;
				}
			}
			getJdbcTemplate().batchUpdate(dSQL);
		}
	}
}
