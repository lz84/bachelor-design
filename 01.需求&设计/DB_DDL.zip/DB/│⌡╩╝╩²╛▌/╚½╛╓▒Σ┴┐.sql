prompt Importing table T_UFP_GV...
set feedback off
set define off
insert into T_UFP_GV (NAME, DESCRIPTION, VALUE, FLAG, ID)
values ('pageRowNum', 'ÿҳ����', '10', '1', '8a1c52923eb02d7e013eb02e7a1e0000');

prompt Done.
