/*
 * @(#)ProjectInfoServiceImpl.java	Mar 11, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.ps.domain.ProjectInfo;
import cn.com.bpsc.ufp.ps.domain.ProjectModule;
import cn.com.bpsc.ufp.ps.domain.ProjectProperty;
import cn.com.bpsc.ufp.ps.service.IProjectInfoService;
import cn.com.bpsc.ufp.ps.service.IProjectModuleService;
import cn.com.bpsc.ufp.ps.service.IProjectPropertyService;

@Service
public class ProjectInfoServiceImpl implements IProjectInfoService {
	
	@Autowired
	private IProjectPropertyService ppService;
	
	
	@Autowired
	private IProjectModuleService pmService;	

	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectInfoService#getPM()
	 */
	@Override
	public ProjectInfo findPI() {
		ProjectInfo pi = new ProjectInfo();
		ProjectProperty pp = ppService.get();
		pi.setPp(pp);
		
//		List<ProjectModule> pmList = pmService.findAll(null);
//		pi.setPmList(pmList);
		return pi;
	}

}
