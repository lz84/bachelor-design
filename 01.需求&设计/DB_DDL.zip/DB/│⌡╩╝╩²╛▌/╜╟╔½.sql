prompt Importing table T_UFP_AUTH_ROLE...
set feedback off
set define off
insert into T_UFP_AUTH_ROLE (NAME, MEMO, DESCRIPTION, ID, DEL_FLAG, TYPE, GROUP_ID, SHOW_ORDER, ROWID)
values ('superadmin', '��������Ա', '��̨ά����', '8a1c53cc3f5a637f013f5a67e4e0001e', '0', 'security-role', null, null, 'AAAdnCAAJAAADGkAAD');

insert into T_UFP_AUTH_ROLE (NAME, MEMO, DESCRIPTION, ID, DEL_FLAG, TYPE, GROUP_ID, SHOW_ORDER, ROWID)
values ('guest', 'δ��¼��ɫ', 'δ��¼��ɫ', '8a1c52923f84efea013f84f36ae2003b', '1', null, 'fafa39a541c5619d0141c563b9940000', '0', 'AAAdnCAAJAAAGKGAAA');

insert into T_UFP_AUTH_ROLE (NAME, MEMO, DESCRIPTION, ID, DEL_FLAG, TYPE, GROUP_ID, SHOW_ORDER, ROWID)
values ('logined', '�ѵ�¼��δ��Ȩ��ɫ', '�ѵ�¼��ɫ', 'fafa39a541c5619d0141c564e0420001', '0', null, 'fafa39a541c5619d0141c563b9940000', null, 'AAAdnCAAJAAAGKGAAD');

insert into T_UFP_AUTH_ROLE (NAME, MEMO, DESCRIPTION, ID, DEL_FLAG, TYPE, GROUP_ID, SHOW_ORDER, ROWID)
values ('authed', '�ѵ�¼������Ȩ��ɫ', '����Ȩ��ɫ', 'fafa39a541c5619d0141c56550ce0002', '0', null, 'fafa39a541c5619d0141c563b9940000', null, 'AAAdnCAAJAAAGKGAAE');

prompt Done.
