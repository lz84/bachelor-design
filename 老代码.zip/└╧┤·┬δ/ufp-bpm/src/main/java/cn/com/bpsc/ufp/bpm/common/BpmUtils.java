package cn.com.bpsc.ufp.bpm.common;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;

public class BpmUtils {

	private static Log log = LogFactory.getLog(BpmUtils.class);
	
	private static final String PRE_STR="\"";
	private static final String END_STR="\"";

//	public static String resolveGroupExp(RuntimeService runtimeService,
//			String groupExp, String processInstanceId) {
//
//		String resolvedGroupName = null;
//		String groupId = getVariableName(StringUtils.substringBeforeLast(
//				groupExp, "#"));
//		String orgVarName = getVariableName(StringUtils.substringAfterLast(
//				groupExp, "#"));
//		String orgValue = "";
//		String groupValue="";
//		BaseBpDataEx bpDataEx = (BaseBpDataEx) runtimeService.getVariable(
//				processInstanceId, Constant.BPM_BP_DATA_EX_KEY);
//		if (processInstanceId != null) {
//			try {
//				orgValue = BeanUtils.getProperty(bpDataEx, orgVarName);
//				groupValue = BeanUtils.getProperty(bpDataEx, groupId);
//				resolvedGroupName = groupValue + "#" + orgValue;
//			} catch (Exception e) {
//				log.error("解析待办人出错，表达式：" + groupExp, e);
//			}
//		} else {
//			orgValue = orgVarName;
//			resolvedGroupName = groupId + "#" + orgValue;
//		}
//		return resolvedGroupName;
//	}

	public static boolean isCandidateGroup(IdentityLink il) {
		if (!StringUtils.isEmpty(il.getGroupId())
				&& il.getType().equals(IdentityLinkType.CANDIDATE)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean haveOrgInfo(String groupId) {
		return StringUtils.contains(groupId, "#");
	}

	private static String getVariableName(String variableStr) {
//		String variableName = StringUtils.substringBeforeLast(
//				(StringUtils.substringAfterLast(variableStr, "${")), "}");
		return variableStr;

	}

}
