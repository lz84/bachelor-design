/*
 * @(#)IGlobalEnumDao.java	May 14, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.gv.dao;

import java.util.List;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.gv.domain.GlobalEnum;
import cn.com.bpsc.ufp.gv.vo.GlobalEnumTvVo;

/**
 * 全局枚举Dao接口
 * 
 * @author 胡斌
 *
 */
public interface IGlobalEnumDao extends IGenericDao<GlobalEnum, String>{

	public List<GlobalEnum> findByEnumName(String enumId);
	
	public List<GlobalEnum> findAllEnumInfo(GlobalEnum ge);
	
	public  List<GlobalEnumTvVo> findByEnumNameTV(String enumName);
	
	public void batchDelete(String[] dSQL);
}
