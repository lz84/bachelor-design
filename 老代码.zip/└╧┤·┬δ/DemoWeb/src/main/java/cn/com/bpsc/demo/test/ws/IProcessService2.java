package cn.com.bpsc.demo.test.ws;

import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public interface IProcessService2 {

	public boolean startProcessCj(@WebParam(name = "isWeek") boolean isWeek,
			@WebParam(name = "userId") String userId,
			@WebParam(name = "password") String password);

	public boolean startProcessFb(
			@WebParam(name = "userId") String userId,
			@WebParam(name = "password") String password);
}
