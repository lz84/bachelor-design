package cn.com.bpsc.ufp.bpm.domain;

/**
 * 节点类型
 * @author 
 *
 */
public enum TaskType {

	审核,会审;
}
