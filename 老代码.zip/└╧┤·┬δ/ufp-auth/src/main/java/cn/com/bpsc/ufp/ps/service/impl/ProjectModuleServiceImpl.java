/*
 * @(#)ProjectModuleServiceImpl.java	Mar 11, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.ps.dao.IProjectModuleDao;
import cn.com.bpsc.ufp.ps.domain.Function;
import cn.com.bpsc.ufp.ps.domain.ProjectModule;
import cn.com.bpsc.ufp.ps.service.IProjectModuleService;

@Service
public class ProjectModuleServiceImpl implements IProjectModuleService {

	@Autowired
	private IProjectModuleDao dao = null;
	
	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectModuleService#save(cn.com.bpsc.ufp.ps.domain.ProjectModule)
	 */
	@Override
	public void save(ProjectModule pm) {
		dao.save(pm);
	}

	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectModuleService#delete(cn.com.bpsc.ufp.ps.domain.ProjectModule)
	 */
	@Override
	public void delete(ProjectModule pm) { 
		dao.delete(pm);
	}

	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectModuleService#update(cn.com.bpsc.ufp.ps.domain.ProjectModule)
	 */
	@Override
	public void update(ProjectModule pm) {
		dao.update(pm);
	}

	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectModuleService#findByName(java.lang.String)
	 */
	@Override
	public ProjectModule findByName(String id) {
		return dao.findById(id);
	}

	/* (non-Javadoc)
	 * @see cn.com.bpsc.ufp.ps.service.IProjectModuleService#findAll(java.lang.String)
	 */
	@Override
	public List<ProjectModule> findChildren(String parentModuleName) {
		
		return dao.findModule(parentModuleName);
	}

	@Override
	public void saveOrUpdate(ProjectModule pm) {
		
		dao.saveOrUpdate(pm);
	}

	@Override
	public ProjectModule findByCode(String code) {
		List<ProjectModule> pms = dao.findByCode(code);
		ProjectModule pm = new ProjectModule();
		if(pms!=null && pms.size()>0){
			pm = pms.get(0);
		}
		return pm;
	}

	@Override
	public List<ProjectModule> findModuleByParentId(String pid) {

		return dao.findModuleByParentId(pid);
	}

	@Override
	public void deleteById(String moduleId) {

		dao.deleteById(moduleId);
	}

}
