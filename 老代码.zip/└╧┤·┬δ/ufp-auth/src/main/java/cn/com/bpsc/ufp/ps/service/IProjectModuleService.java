/*
 * @(#)IProjectModuleService.java	Mar 11, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service;

import java.util.List;

import cn.com.bpsc.ufp.ps.domain.ProjectModule;

/**
 * @author ���
 *
 */
public interface IProjectModuleService {
	
	public void save(ProjectModule pm);
	
	public void delete(ProjectModule pm);
	
	public void update(ProjectModule pm);
	
	public ProjectModule findByName(String id);
	
	public List<ProjectModule> findChildren(String parentModuleName);
	
	public void saveOrUpdate(ProjectModule pm);
	
	public	ProjectModule findByCode(String code);
	
	public List<ProjectModule> findModuleByParentId(String pid);
	
	/**
	 * 删除模块
	 * @param moduleId
	 */
	public void deleteById(String moduleId);
}
