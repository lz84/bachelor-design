prompt Importing table T_UFP_PS_PROPERTY...
set feedback off
set define off
insert into T_UFP_PS_PROPERTY (NAME, TITLE, SUBTITLE, VERSION, COPYRIGHT, LOGO_URL, ACCESS_IP, ACCESS_DNS, PORT, CONTEXT, INDEX_PATH, LOGIN_SHOW_PATH, ERROR_PATH, ERROR_MSG, INFO_PATH, INFO_MSG, ID, BUSINESS_DOMAIN_ID, LOGIN_AUTH_PATH)
values ('DemoWeb', 'ƽ̨Demo����', 'ƽ̨Demo����', '1.0.0', '����������ϢͨѶ�ֹ�˾', null, null, null, null, 'DemoWeb', '/index.htm', '/login/index.htm', 'error', null, null, null, '1111', '8a1c52923da96b85013da96fd6280000', '/login/login.htm');

prompt Done.
