package cn.com.bpsc.demo.test.biz;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ThreadTest {

	private int j;
	private Lock lock = new ReentrantLock();
	
	public static void main(String[] args) {
		ThreadTest tt = new ThreadTest();
		for(int i=0 ;i<2; i++){
			new Thread(tt.new Addr()).start();
			new Thread(tt.new Sub()).start();
		}
	}
	
	class Addr implements Runnable{

		@Override
		public void run() {
			while(true){
				lock.lock();
				try{
					System.out.println("j++=" + j++);
				}finally{
					lock.unlock();
				}
			}
			
		}
		
	}
	
	class Sub implements Runnable{

		@Override
		public void run() {
			while(true){
				lock.lock();
				try{
					System.out.println("j--=" + j--);
				}finally{
					lock.unlock();
				}
			}
			
		}
		
	}
	
}
