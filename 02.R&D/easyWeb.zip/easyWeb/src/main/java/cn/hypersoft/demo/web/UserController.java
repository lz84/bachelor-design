/**
 * 
 */
package cn.hypersoft.demo.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hypersoft.demo.entities.User;
import cn.hypersoft.demo.service.UserService;

/**
 * @author DELL
 * 
 */
@Controller
@RequestMapping(value = "/users")
public class UserController {
	@Autowired
	UserService userService;

	@RequestMapping(method = RequestMethod.GET)
	public String getUsers(Model model) {
		Iterable<User> users = userService.findAll();
		model.addAttribute("users", users);
		return "user-list";
	}
	@RequestMapping(value = "/input", method = RequestMethod.POST)
	@ResponseBody
	String input(@RequestParam String name) {
		return "Welcome ," + name + "!";
	}

	@RequestMapping(value = "{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public User findUser(@PathVariable("id") long id) {
		return userService.findById(id);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Void> deleteUser(@PathVariable("id") int id) {
		userService.deleteUser(id);
		return new ResponseEntity(HttpStatus.OK);
	}

}
