package cn.com.bpsc.ufp.stat.dao;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.stat.domain.StatAop;

public interface IStatAopDao extends IGenericDao<StatAop,String>{
	
	public void batchDelete(String delInfo);
}
