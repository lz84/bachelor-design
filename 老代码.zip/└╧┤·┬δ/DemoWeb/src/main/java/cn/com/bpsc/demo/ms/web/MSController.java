package cn.com.bpsc.demo.ms.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.com.bpsc.demo.ms.bp.MS_ParentBpDataEx;
import cn.com.bpsc.demo.ms.bp.MS_SubBpDataEx;
import cn.com.bpsc.ufp.auth.service.ILoginService;
import cn.com.bpsc.ufp.bpm.domain.TaskEx;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeTaskService;
import cn.com.bpsc.ufp.bpm.vo.PiStatus;
import cn.com.bpsc.ufp.org.domain.User;

/**
 * 多实例子流程Demo的web controller
 * 
 * @author 
 * @since 1.0.0
 */
@Controller
@RequestMapping("test/ms")
public class MSController {
	
	@Autowired
	private IBpmRuntimeService bpmRuntimeService;
	
	@Autowired
	private IBpmRuntimeTaskService bpmTaskService;
	
	@Autowired
	private ILoginService loginService;

	/**
	 * 启动父流程
	 * 
	 * @param pdId
	 * @param bizkey
	 * @return
	 */
	@RequestMapping("start")
	@ResponseBody
	public Map<String,String> start(@RequestParam String pdkey, @RequestParam String bizkey){
		//登录，启动流程的前提条件
		loginService.login("c", "123456");
		
		
		//准备流程数据
		MS_ParentBpDataEx parentData = new MS_ParentBpDataEx();
		parentData.setDomainId(bizkey);
		
		MS_SubBpDataEx subData = new MS_SubBpDataEx();
		subData.setTestAssigneer("c");
		parentData.getSubBpDataList().add(subData);
		
		subData = new MS_SubBpDataEx();
		subData.setTestAssigneer("mafeih");
		parentData.getSubBpDataList().add(subData);
		
		subData = new MS_SubBpDataEx();
		subData.setTestAssigneer("zhangtaof");
		parentData.getSubBpDataList().add(subData);
		
		//启动流程
		ProcessInstance pi = bpmRuntimeService.startProcessInstanceByKey(pdkey, parentData);
		
		//设置返回信息
		Map<String,String> result = new HashMap<String,String>();
		result.put("executionId", pi.getId());
		result.put("parentId", pi.getParentId());
		result.put("activityId", pi.getActivityId());
		result.put("pdId", pi.getProcessDefinitionId());
		result.put("piId", pi.getProcessInstanceId());
		result.put("bizKey", pi.getBusinessKey());
		
		return result;
	}
	

	@RequestMapping("complete")
	public String complete(@RequestParam String taskId){
		
		
		return "ok";
	}	
	

	@RequestMapping("queryAssigneerByBizKey")
	@ResponseBody
	public List<User> queryAssigneerByBizKey(@RequestParam String bizKey){
		List<User> users = bpmRuntimeService.getTaskCandidateUserByBizKey(bizKey);
		
		return users;
	}
	
	@RequestMapping("queryPiStatus")
	@ResponseBody
	public PiStatus queryPiStatus(@RequestParam String bizKey){
		PiStatus piStatus = bpmRuntimeService.getPiStatusByBizKey(bizKey);
		
		return piStatus;
	}

	@RequestMapping("queryTaskByPdKeyAndUser")
	@ResponseBody
	public List<String> queryTaskByPdKeyAndUser(@RequestParam String pdKey, @RequestParam String userId){
		List<TaskEx> taskExList = bpmTaskService.getTaskByAssignee(pdKey, userId);
		if(taskExList == null || taskExList.size() <= 0){
			return null;
		}else{
			List<String> tasks = new ArrayList<String>();
			for(TaskEx taskEx: taskExList){
				tasks.add(taskEx.getTask().getId());
			}
			
			return tasks;
		}
		
	}
	
}
