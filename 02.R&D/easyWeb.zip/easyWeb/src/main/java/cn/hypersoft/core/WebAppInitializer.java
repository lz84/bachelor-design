package cn.hypersoft.core;

import javax.servlet.Filter;

import org.springframework.orm.jpa.support.OpenEntityManagerInViewFilter;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import cn.hypersoft.common.Constants;

/**
 * webӦ�ó�ʼ����������
 * 
 * @author sunchangqing
 * 
 */
// @Order(2)
public class WebAppInitializer extends
		AbstractAnnotationConfigDispatcherServletInitializer {

	/**
	 * Ӧ�ù�������ȫ�������־û�����
	 */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class<?>[] { AppConfig.class, SecurityConfig.class,
				PersistenceConfig.class, BizConfig.class };
	}

	/**
	 * web����
	 */
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class<?>[] { WebConfig.class };
	}

	/**
	 * web Ӧ��ӳ���Ŀ¼
	 */
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

	/**
	 * filter����
	 */
	@Override
	protected Filter[] getServletFilters() {

		CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
		characterEncodingFilter.setEncoding(Constants.APP_CHARACTER_ENCODING);
		return new Filter[] { characterEncodingFilter,
				new DelegatingFilterProxy("springSecurityFilterChain"),
				new OpenEntityManagerInViewFilter() };
	}
}
