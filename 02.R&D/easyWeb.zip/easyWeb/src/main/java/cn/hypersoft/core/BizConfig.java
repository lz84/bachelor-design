/**
 * 
 */
package cn.hypersoft.core;

import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author DELL
 * 
 */
@Configuration
@EnableTransactionManagement
public class BizConfig {

}
