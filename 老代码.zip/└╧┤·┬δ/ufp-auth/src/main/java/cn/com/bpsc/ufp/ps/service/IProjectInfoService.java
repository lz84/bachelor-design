/*
 * @(#)IProjectInfoService.java	Mar 11, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service;

import cn.com.bpsc.ufp.ps.domain.ProjectInfo;

/**
 * @author 胡斌
 *
 */
public interface IProjectInfoService {

	/**
	 * 查找项目的属性信息和模块结构
	 * 
	 * @return 项目的属性信息和模块结构
	 */
	public ProjectInfo findPI();
}
