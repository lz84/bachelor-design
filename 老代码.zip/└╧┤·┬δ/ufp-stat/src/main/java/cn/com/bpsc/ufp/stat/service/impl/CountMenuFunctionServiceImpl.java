package cn.com.bpsc.ufp.stat.service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.auth.domain.StatisticController;
import cn.com.bpsc.ufp.stat.dao.ICountMenuFunctionDao;
import cn.com.bpsc.ufp.stat.service.ICountMenuFunctionService;
import cn.com.bpsc.ufp.stat.vo.CountConditionVo;

@Service
public class CountMenuFunctionServiceImpl implements ICountMenuFunctionService{

	@Autowired
	private ICountMenuFunctionDao countMenuFunctionDao = null;
	
	@Override
	public List countSystemRunEfficiency(CountConditionVo cc) {
		 
		return countMenuFunctionDao.countSystemRunEfficiency(cc);
	}

	@Override
	public void save(StatisticController sc) {
 
		countMenuFunctionDao.saveInfo(sc);
	}

}
