/*
 * @(#)ProjectPropertyDaoImpl.java	Mar 8, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.dao.impl;

import org.springframework.stereotype.Repository;

import cn.com.bpsc.ufp.dao.impl.GenericDaoImpl;
import cn.com.bpsc.ufp.ps.dao.IProjectPropertyDao;
import cn.com.bpsc.ufp.ps.domain.ProjectProperty;

@Repository
public class ProjectPropertyDaoImpl extends GenericDaoImpl<ProjectProperty, String>  implements IProjectPropertyDao{

}
