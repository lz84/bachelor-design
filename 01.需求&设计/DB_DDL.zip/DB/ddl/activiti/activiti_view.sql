-------------------------------------------
-- Export file for user UFP_DEMO         --
-- Created by user on 2013-7-17, 9:48:34 --
-------------------------------------------

spool activiti_view.log

prompt
prompt Creating view ACT_ID_GROUP
prompt ==========================
prompt
create or replace view act_id_group as
select t.name id_, '1' rev_, t.description name_, t.type type_, t.id table_row_id_
    from t_ufp_auth_role t
/

prompt
prompt Creating view ACT_ID_MEMBERSHIP
prompt ===============================
prompt
create or replace view act_id_membership as
select t.user_id user_id_, r.name group_id_
    from t_ufp_auth_role_user t left join t_ufp_auth_role r on t.role_id = r.id
/

prompt
prompt Creating view ACT_ID_USER
prompt =========================
prompt
create or replace view act_id_user as
select t.id id_, '1' rev_, t.username first_, '' last_, '' email_, t.pwd pwd_, null picture_id_
    from t_ufp_user t
/


spool off
