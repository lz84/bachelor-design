package cn.com.bpsc.ufp.auth.dao;
import cn.com.bpsc.ufp.auth.domain.StatisticController;
import cn.com.bpsc.ufp.dao.IGenericDao;

public interface IStatisticControllerDao  extends IGenericDao<StatisticController, String>{

}
