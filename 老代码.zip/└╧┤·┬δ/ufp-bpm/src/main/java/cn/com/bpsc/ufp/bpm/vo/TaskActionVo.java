package cn.com.bpsc.ufp.bpm.vo;

import java.util.Date;
import java.util.List;

import cn.com.bpsc.ufp.org.domain.Org;
import cn.com.bpsc.ufp.org.domain.User;

public class TaskActionVo {

	private User operator;
	private Org operCompany;
	private Date startDate;
	private Date completeDate;
	private List<String> comments;
	public List<String> getComments() {
		return comments;
	}
	public void setComments(List<String> comments) {
		this.comments = comments;
	}
	public User getOperator() {
		return operator;
	}
	public void setOperator(User operator) {
		this.operator = operator;
	}
	public Org getOperCompany() {
		return operCompany;
	}
	public void setOperCompany(Org operCompany) {
		this.operCompany = operCompany;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getCompleteDate() {
		return completeDate;
	}
	public void setCompleteDate(Date completeDate) {
		this.completeDate = completeDate;
	}
	
}
