package cn.com.bpsc.ufp.ps.dao;

import java.util.List;
import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.ps.domain.ProjectModuleExt;

public interface IProjectModuleExtDao extends IGenericDao<ProjectModuleExt, String> {
	
	public List<ProjectModuleExt> findModuleExt(ProjectModuleExt pme);
}
