/**
 * 
 */
package cn.hypersoft.core;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import cn.hypersoft.demo.service.MessageService;
import cn.hypersoft.demo.service.MessageServiceImpl;

/**
 * ҵ���������
 * 
 * @author sunchangqing
 * 
 */
@Configuration
public class ServiceConfig {
	/**
	 * service �����ڴ�ʵ����ͬ������ʹ��annotation
	 * 
	 * @return
	 */
	@Bean
	public MessageService getMessageService() {
		return new MessageServiceImpl();
	}
}
