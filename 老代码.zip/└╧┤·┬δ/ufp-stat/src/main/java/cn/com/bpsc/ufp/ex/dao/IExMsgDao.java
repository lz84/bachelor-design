/*
 * @(#)IExMsgDao.java	Apr 23, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ex.dao;

import java.util.List;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.ex.domain.ExMsg;

/**
 * @author user
 *
 */
public interface IExMsgDao extends IGenericDao<ExMsg,String> {
	
	public List<ExMsg> findExMsgInfo(ExMsg ex);
}
