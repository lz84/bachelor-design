package cn.com.bpsc.ufp.bpm.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.TaskListener;
import org.activiti.engine.task.IdentityLink;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.com.bpsc.ufp.auth.service.IAuthRoleUserService;
import cn.com.bpsc.ufp.bpm.common.BpmUtils;
import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.bpm.service.IGroupExpResolveService;
import cn.com.bpsc.ufp.context.service.IVLService;
import cn.com.bpsc.ufp.org.domain.User;

@Service
public class GroupAndOrgResolverTaskListener implements TaskListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	private TaskService taskService;
	@Autowired
	private RuntimeService runtimeService;
	@Autowired
	private IVLService vlService;
	@Autowired
	private IAuthRoleUserService authRole;
	@Autowired
	private IGroupExpResolveService groupExpResolveService;
	@Autowired
	private IBpmRuntimeService bpmRuntimeService;

	@Override
	public void notify(DelegateTask delegateTask) {
		BaseBpDataEx bpDataEx = new BaseBpDataEx();
		// (BaseBpDataEx)
		// bpmRuntimeService.getBpDataExByTaskId(delegateTask.getId());
		// bpmRuntimeService.getBpDataExByBizKey(delegateTask.getExecution().getBusinessKey());
		Set<String> nameSet = delegateTask.getVariableNames();
		Map busMap = new HashMap();
		try {
			Map map = BeanUtils.describe(bpDataEx);
			for (Object keyObj : map.keySet()) {
				if (!(keyObj instanceof String)) {
					continue;
				}
				String key = keyObj.toString();
				if (key.equals("taskEx")) {
					continue;
				}
				if(key.equals("class")){
					continue;
				}
				Object valueObj = delegateTask.getVariable(key);
				PropertyUtils.setProperty(bpDataEx, key, valueObj);
			}
			for (String valName : nameSet) {
				if (!map.keySet().contains(valName)) {
					busMap.put(valName, delegateTask.getVariable(valName));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		bpDataEx.setBusinessExtMap(busMap);

		Set<IdentityLink> ilList = delegateTask.getCandidates();
		for (IdentityLink il : ilList) {
			if (BpmUtils.isCandidateGroup(il)
					&& BpmUtils.haveOrgInfo(il.getGroupId())) {
				Set<User> users = groupExpResolveService.resolve(
						il.getGroupId(), bpDataEx);
				if (users != null && !users.isEmpty()) {
					for (User user : users) {
						taskService.addCandidateUser(delegateTask.getId(),
								user.getId());
					}
				}

			}
		}

	}

}
