/*
 * @(#)BusinessDomainServiceImpl.java	Mar 26, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.ps.dao.IBusinessDomainDao;
import cn.com.bpsc.ufp.ps.domain.BusinessDomain;
import cn.com.bpsc.ufp.ps.service.IBusinessDomainService;

/**
 * @author user
 *
 */
@Service(value="businessDomainService")
public class BusinessDomainServiceImpl  implements IBusinessDomainService{
	
	@Autowired
	private IBusinessDomainDao dao;
	 
	@Override
	public List<BusinessDomain> findChildren(String parentId) {
		return dao.findChildren(parentId);
	}

	@Override
	public void deleteById(String id) {
		BusinessDomain bd = dao.findById(id);
		dao.delete(bd);
	}

	@Override
	public List<BusinessDomain> findAll() {
		return dao.findAll();
	}

	@Override
	public void save(BusinessDomain bd) {
		dao.save(bd);
	}

}
