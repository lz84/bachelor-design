/**
 * 
 */
package cn.hypersoft.demo.service;

/**
 * @author DELL
 * 
 */
public interface MessageService {
	void printMessage();
}
