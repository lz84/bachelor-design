package cn.com.bpsc.demo.test.ws;

import javax.jws.WebService;
import javax.sql.DataSource;

@WebService(endpointInterface="cn.com.bpsc.demo.test.ws.IProcessService2")
public class ProcessServiceImpl2 implements IProcessService2 {
	
	private DataSource ds;

	@Override
	public boolean startProcessCj(boolean isWeek, String userId, String password) {
		System.out.println("startProcessCj");
		return true;
	}

	@Override
	public boolean startProcessFb(String userId, String password) {
		System.out.println("startProcessFb");
		return true;
	}
	
}
