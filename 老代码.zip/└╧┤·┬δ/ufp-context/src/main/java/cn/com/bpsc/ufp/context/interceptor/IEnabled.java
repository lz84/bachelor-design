package cn.com.bpsc.ufp.context.interceptor;

public interface IEnabled {
	
	public boolean isEnable();
	
	public void setEnable(boolean enable);
	
}
