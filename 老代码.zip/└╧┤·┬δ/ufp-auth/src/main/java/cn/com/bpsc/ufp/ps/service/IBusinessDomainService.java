/*
 * @(#)IBusinessDomainService.java	Mar 26, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.service;

import java.util.List;
import cn.com.bpsc.ufp.ps.domain.BusinessDomain;

/**
 * @author user
 *
 */
public interface IBusinessDomainService   {

	public List<BusinessDomain> findChildren(String parentId);

	public List<BusinessDomain> findAll();

	public void save(BusinessDomain bd);

	public void deleteById(String id);
}
