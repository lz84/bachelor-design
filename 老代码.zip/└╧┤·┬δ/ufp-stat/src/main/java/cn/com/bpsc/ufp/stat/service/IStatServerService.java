package cn.com.bpsc.ufp.stat.service;

import java.util.List;

import cn.com.bpsc.ufp.stat.domain.StatServer;


public interface IStatServerService {
	
	public void saveOrUpdate(StatServer ss);
	
	public List<StatServer> findByExample(StatServer ss);
}
