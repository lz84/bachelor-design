package cn.com.bpsc.ufp.stat.dao;

import java.util.List;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.stat.domain.StatServer;


public interface IStatServerDao  extends IGenericDao<StatServer,String> {
	
	public List<StatServer> findByExample(StatServer ss);
}
