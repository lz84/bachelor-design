package cn.com.bpsc.ufp.stat.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.stat.dao.IStatServerDao;
import cn.com.bpsc.ufp.stat.domain.StatServer;
import cn.com.bpsc.ufp.stat.service.IStatServerService;

@Service
public class StatServerServiceImpl implements IStatServerService {

	@Autowired
	private IStatServerDao statServerDao = null;
	
	@Override
	public void saveOrUpdate(StatServer ss) {
		 
		statServerDao.saveOrUpdate(ss);
	}

	@Override
	public List<StatServer> findByExample(StatServer ss) {
		 
		
		return statServerDao.findByExample(ss);
	}

}
