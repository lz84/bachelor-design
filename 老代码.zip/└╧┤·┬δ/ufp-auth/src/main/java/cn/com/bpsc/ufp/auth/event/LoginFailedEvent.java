/*
 * @(#)LoginSuccessEvent.java	May 8, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.auth.event;

import org.springframework.context.ApplicationEvent;

import cn.com.bpsc.ufp.auth.domain.LoginResult;

/**
 * @author 胡斌
 *
 */
public class LoginFailedEvent extends ApplicationEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5062717669721900150L;
	
	/**
	 * @param source
	 */
	public LoginFailedEvent(LoginResult source) {
		super(source);
	}

}
