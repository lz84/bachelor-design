/**
 * 
 */
package cn.hypersoft.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import cn.hypersoft.demo.service.SecurityUserService;

/**
 * ��ȫ��������
 * 
 * @author sunchangqing
 * 
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	SecurityUserService securityUserService;

	@Override
	protected void configure(AuthenticationManagerBuilder auth)
			throws Exception {
		/*
		 * auth.inMemoryAuthentication()
		 * .withUser("conntsing").password("noshing").roles("USER");
		 */
		auth.userDetailsService(securityUserService);

		// registry.jdbcAuthentication().dataSource(dataSource)
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/resources/**");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable()

		.authorizeRequests().antMatchers("/login/form", "/register", "/logout")
				.permitAll()

				.antMatchers("/security").hasRole("USER").antMatchers("/users")
				.hasRole("ADMIN").anyRequest().authenticated()
				.and()
				// This will generate a login form if none is supplied.
				// .formLogin()

				.formLogin().loginPage("/login/form")
				.loginProcessingUrl("/login").defaultSuccessUrl("/security")
				// һЩ��½����
				// .successHandler(successHandler)
				.failureUrl("/login/error").permitAll();
	}

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}
}
