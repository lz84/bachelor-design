/*
 * @(#)IBusinessDomainDao.java	Mar 26, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.dao;

import java.util.List;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.ps.domain.BusinessDomain;

/**
 * @author user
 *
 */
public interface IBusinessDomainDao extends IGenericDao<BusinessDomain, String>{


	/**
	 * @param parentId
	 */
	public List<BusinessDomain> findChildren(String parentId) ;
}
