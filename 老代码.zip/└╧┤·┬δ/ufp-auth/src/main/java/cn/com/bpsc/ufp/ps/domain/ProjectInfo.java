/*
 * @(#)ProjectInfo.java	Mar 11, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.ps.domain;

import java.util.List;

/**
 * @author 胡斌
 *
 */
public class ProjectInfo {

	private ProjectProperty pp;
	private List<ProjectModule> pmList;
	/**
	 * @return the pp
	 */
	public ProjectProperty getPp() {
		return pp;
	}
	/**
	 * @param pp the pp to set
	 */
	public void setPp(ProjectProperty pp) {
		this.pp = pp;
	}
	/**
	 * @return the pmList
	 */
	public List<ProjectModule> getPmList() {
		return pmList;
	}
	/**
	 * @param pmList the pmList to set
	 */
	public void setPmList(List<ProjectModule> mmList) {
		this.pmList = mmList;
	}
	
	
}
