/**
 * 
 */
package cn.hypersoft.demo.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import cn.hypersoft.demo.entities.User;

/**
 * @author DELL
 * 
 */
@Repository
public interface UserDao extends CrudRepository<User, Long> {

	User findByLoginId(String lastName);

	public User findById(long id);

	@Query("select u from User u where u.loginId=?1 and u.password=?2")
	User login(String email, String password);
}
