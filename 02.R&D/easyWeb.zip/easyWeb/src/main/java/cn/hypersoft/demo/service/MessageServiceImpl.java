/**
 * 
 */
package cn.hypersoft.demo.service;

/**
 * @author DELL
 * 
 */
public class MessageServiceImpl implements MessageService {
	@Override
	public void printMessage() {
		System.out.println("hello");
	}

}
