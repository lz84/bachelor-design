/*
 * @(#)IRoleDao.java	Mar 18, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.auth.dao;

import java.util.List;

import cn.com.bpsc.ufp.auth.domain.Role;
import cn.com.bpsc.ufp.dao.IGenericDao;


public interface IRoleDao extends IGenericDao<Role, String>{
	
	public List<Role> findAllRoleInfo();
	
	public void batchDelete(String[] delInfo); 
	
	public Role findByName(String roleName);
	
	public Role findRoleEtyByName(String roleName);
}
