package cn.com.bpsc.ufp.auth.dao;

import java.util.List;

import cn.com.bpsc.ufp.dao.IGenericDao;
import cn.com.bpsc.ufp.org.domain.User;

public interface IUserManagerDao extends IGenericDao<User, String> {

	public List<User> findByExample(User user);
	
	public List<User> validateById(String id);
	 
}
