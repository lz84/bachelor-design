package cn.com.bpsc.ufp.console.org.web;

import java.util.Set;

import cn.com.bpsc.ufp.org.domain.Org;
import cn.com.bpsc.ufp.web.ztree.ZTreeNodeAdapter;
import cn.com.bpsc.ufp.web.ztree.ZTreeTreeNode;

public class OrgZTreeAdapter implements ZTreeNodeAdapter<Org>{

	@Override
	public ZTreeTreeNode toZTreeNodeModel(Org org) {
		ZTreeTreeNode node = new ZTreeTreeNode();
		node.setId(org.getId());
		node.setName(org.getName());
		node.setIsParent(false);
		if(org.getIsChildren()!=null && org.getIsChildren()>0){
			node.setIsParent(true);
		}
		return node;
	}

	@Override
	public Set<Org> getChildren(Org org) {
		
		return org.childModules;
	}

}
