/*
 * @(#)UtilConstant.java	Jun 5, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.util;

/**
 * @author user
 *
 */
public class UtilConstant {

	public static final String STATISTIC_REQUEST = "statistic_request";
}
