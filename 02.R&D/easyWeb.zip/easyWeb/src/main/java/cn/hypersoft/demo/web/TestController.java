/**
 * 
 */
package cn.hypersoft.demo.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.hypersoft.demo.service.MessageService;

/**
 * @author DELL
 * 
 */
@Controller
// @EnableAutoConfiguration
public class TestController {

	@Autowired
	MessageService messageService;

	@RequestMapping("/test")
	@ResponseBody
	String home() {
		messageService.printMessage();
		return "suc";
	}

	@RequestMapping("/test2")
	String test() {
		return "index";
	}
	//
	// public static void main(String[] args) throws Exception {
	// SpringApplication.run(TestController.class, args);
	// }
}
