/**
 * 
 */
package cn.hypersoft.utils;

/**
 * @author DELL
 * 
 */
public class MD5 {
	public static String str2MD5(String str) {
		return str;
	}
}
