package cn.com.bpsc.ufp.context.common;

public class ContextConstant {

	public static final String WEB_CONTEXT_NAME = "ufp_conext_name";
	
	public static final String WEB_DOC_ROOT = "ufp_context_doc_root";

	public static final Object WEB_PROJECT_NAME = "/appconsoleWeb";
	
}
