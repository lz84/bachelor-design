package cn.com.bpsc.demo.test.biz.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.bpsc.demo.test.biz.ITestWsBiz;
import cn.com.bpsc.ufp.context.service.IVLService;

@Service
public class TestWsBizImpl implements ITestWsBiz {

	@Autowired
	private IVLService vlService;
	
	@Override
	public String getMsg() {
		String msg = (String)vlService.getRequestAttribute("MSG");
		return msg;
	}

}
