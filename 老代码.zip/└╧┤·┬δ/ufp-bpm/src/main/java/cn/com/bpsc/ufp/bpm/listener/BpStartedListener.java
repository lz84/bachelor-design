package cn.com.bpsc.ufp.bpm.listener;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Service;

import cn.com.bpsc.ufp.bpm.common.Constant;
import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.bpm.domain.BpStartedEvent;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.context.service.IVLService;

@Service
public class BpStartedListener implements ApplicationListener<BpStartedEvent>{
	@Autowired
	private IVLService vlService;
	
	@Autowired
	private IBpmRuntimeService bpmRuntimeService;
	
	@Override
	public void onApplicationEvent(BpStartedEvent event) {
//		BaseBpDataEx  bpDataEx=(BaseBpDataEx) event.getSource();
//		BaseBpDataEx newBpDateEx = bpmRuntimeService.getBpDataEx(bpDataEx.getPiId());
//		vlService.setRequestAttribute(Constant.BPM_BP_DATA_EX_KEY, newBpDateEx);
	}
	
}
