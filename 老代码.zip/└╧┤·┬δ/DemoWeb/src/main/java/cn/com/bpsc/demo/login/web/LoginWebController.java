/*
 * @(#)LoginWebController.java	May 22, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.demo.login.web;

import java.util.List;

import org.activiti.engine.HistoryService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cn.com.bpsc.ufp.auth.common.AuthConstant;
import cn.com.bpsc.ufp.auth.domain.LoginResult;
import cn.com.bpsc.ufp.auth.service.ILoginService;
import cn.com.bpsc.ufp.bpm.common.Constant;
import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.facade.service.IContextService;
import cn.com.bpsc.ufp.facade.service.impl.BpmContextService;

/**
 * @author
 *
 */
@Controller
@RequestMapping("login")
public class LoginWebController {

	@Autowired
	private ILoginService loginService;
	
	@Autowired
	private IContextService ctxService;
	
	@Autowired
	private HistoryService historyService;
	
	@RequestMapping("index")
	public ModelAndView index(){
		return new ModelAndView("login/login");
	}
	@RequestMapping("login")
	public ModelAndView login(String userId, String pwd){
		LoginResult result = loginService.login(userId, pwd);
		if(result.getResult() == AuthConstant.RESULT_SUCCESS){
			String index = ctxService.getProjectProperty().getIndexPath();
			/*ModelAndView mav = new ModelAndView("redirect:/report/index.htm");
			return mav;*/
			return new ModelAndView("redirect:" + index);
		}else{
			String loginPath = ctxService.getProjectProperty().getLoginShowPath();
			
			return new ModelAndView("forward:" + loginPath);
		}
	}
	
	@RequestMapping("logoff")
	public ModelAndView logoff(){
		ctxService.removeSessionAttribute(AuthConstant.LOGIN_USER);
		ctxService.removeSessionAttribute(AuthConstant.LOGIN_USER_CLIENT);
		ctxService.removeSessionAttribute(AuthConstant.LOGIN_USER_ROLE);
		String loginPath = ctxService.getProjectProperty().getLoginShowPath();
		return new ModelAndView("redirect:" + loginPath);
	}
}