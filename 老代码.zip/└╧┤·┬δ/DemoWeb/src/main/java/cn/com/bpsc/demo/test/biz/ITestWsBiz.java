package cn.com.bpsc.demo.test.biz;

public interface ITestWsBiz {

	public String getMsg();
}
