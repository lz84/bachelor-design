package cn.com.bpsc.aqzs.web.service.impl;

import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;

import cn.com.bpsc.aqzs.common.service.IProcessService;
import cn.com.bpsc.ufp.auth.common.AuthConstant;
import cn.com.bpsc.ufp.auth.domain.LoginResult;
import cn.com.bpsc.ufp.auth.service.ILoginService;
import cn.com.bpsc.ufp.context.service.IVLService;

@WebService(targetNamespace = "http://service.web.aqzs.bpsc.com.cn/", endpointInterface = "cn.com.bpsc.aqzs.common.service.IProcessService")
public class ProcessServiceImpl implements IProcessService{

	@Autowired
	private IVLService vlService;
	@Autowired
	private ILoginService loginService;
	
	@Override
	public boolean startProcessCj(boolean isWeek, String userId, String password) {
		System.out.println("startProcessCj");
		LoginResult result = loginService.login(userId, password);
		vlService.setRequestAttribute(AuthConstant.LOGIN_USER, result.getUser());
		return true;
	}

	@Override
	public boolean startProcessFb(String userId, String password) {
		System.out.println("startProcessFb");
		return true;
	}

}
