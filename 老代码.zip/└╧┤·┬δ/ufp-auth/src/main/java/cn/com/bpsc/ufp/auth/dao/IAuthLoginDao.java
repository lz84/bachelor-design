package cn.com.bpsc.ufp.auth.dao;

import java.util.List;

import cn.com.bpsc.ufp.auth.domain.AuthLogin;
import cn.com.bpsc.ufp.dao.IGenericDao;

public interface IAuthLoginDao extends IGenericDao<AuthLogin, String>{

	public List<AuthLogin> findByExample(AuthLogin al);
}
