package cn.com.bpsc.ufp.bpm.domain;

import java.io.Serializable;

/**
 * 子流程和业务系统数据交换基类
 * 
 * @author 
 * @since 1.0.0
 */
public class BaseSubBpDataEx implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/** 子流程对应的业务Domain Id **/
	private String subDomainId;
	
	/** 相关单位Id **/
	private String companyId;
	
	/** 相关单位名称 **/
	private String companyName;

	/** 相关单位简称 **/
	private String companyShortName;
	
	/**
	 * 取得子流程对应的业务Id
	 * 
	 * @return 子流程对应的业务Id
	 */
	public String getSubDomainId() {
		return subDomainId;
	}

	/**
	 * 设置子流程对应的业务Id
	 * 
	 * @param subDomainId 子流程对应的业务Id
	 */
	public void setSubDomainId(String subDomainId) {
		this.subDomainId = subDomainId;
	}

	/**
	 * 取得相关单位Id
	 * 
	 * @return 相关单位Id
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * 设置相关单位Id
	 * 
	 * @param companyId 相关单位Id
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * 取得相关单位名称
	 * 
	 * @return 相关单位名称
	 */
	public String getCompanyName() {
		return companyName;
	}

	
	/**
	 * 设置相关单位名称
	 * 
	 * @param companyName 相关单位名称
	 */	
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * 取得相关单位简称
	 * 
	 * @return 相关单位简称
	 */
	public String getCompanyShortName() {
		return companyShortName;
	}

	/**
	 * 设置相关单位简称
	 * 
	 * @param companyName 相关单位简称
	 */
	public void setCompanyShortName(String companyShortName) {
		this.companyShortName = companyShortName;
	}
	
	
}
