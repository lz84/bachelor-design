package cn.com.bpsc.ufp.console.ps.web;

import java.util.Set;

import cn.com.bpsc.ufp.ps.domain.BusinessDomain;
import cn.com.bpsc.ufp.web.ztree.ZTreeNodeAdapter;
import cn.com.bpsc.ufp.web.ztree.ZTreeTreeNode;

public class BusinessDomainZTreeAdapter implements ZTreeNodeAdapter<BusinessDomain>{

	@Override
	public ZTreeTreeNode toZTreeNodeModel(BusinessDomain businessDomain) {
		ZTreeTreeNode node = new ZTreeTreeNode();
		node.setId(businessDomain.getId());
		node.setName(businessDomain.getName());
		return node;
	}

	@Override
	public Set<BusinessDomain> getChildren(BusinessDomain businessDomain) {
		
		return businessDomain.getChildren();
	}

}
