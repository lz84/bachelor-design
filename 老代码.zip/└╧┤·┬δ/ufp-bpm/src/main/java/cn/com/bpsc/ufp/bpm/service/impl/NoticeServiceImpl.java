package cn.com.bpsc.ufp.bpm.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import cn.com.bpsc.ufp.auth.domain.Role;
import cn.com.bpsc.ufp.auth.service.IRoleService;
import cn.com.bpsc.ufp.bpm.dao.INoticeDao;
import cn.com.bpsc.ufp.bpm.domain.Notice;
import cn.com.bpsc.ufp.bpm.service.INoticeService;
import cn.com.bpsc.ufp.org.domain.Org;
import cn.com.bpsc.ufp.org.domain.User;
import cn.com.bpsc.ufp.org.service.IOrgService;
import cn.com.bpsc.ufp.org.service.IUserService;

@Service
public class NoticeServiceImpl implements INoticeService {

	@Autowired
	private INoticeDao noticeDao;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IRoleService roleService;
	
	@Autowired
	private IOrgService orgService;
	@Override
	public Notice publish(String title, String content, String Url,
			List<String> userIdList, String creatorId) {
		Notice notice = new Notice();
		User user = userService.findById(creatorId);
		notice.setCreateTime(new Date());
		notice.setTitle(title);
		notice.setContent(content);
		notice.setUrl(Url);
		notice.setSenderId(user.getId());
		notice.setSenderName(user.getUsername());
		noticeDao.save(notice);
		saveNoticeReceiverInfo(userIdList,notice.getId());
		return notice;
	}
	
	/**
	 * 保存接收人员信息
	 * @param userIdList
	 * @param noticeId
	 */
	private void saveNoticeReceiverInfo(List<String> userIdList,String noticeId){
		if(userIdList!=null && userIdList.size()>0){
			String cSQL[] = new String[userIdList.size()];
			int index = 0;
			for(String userId:userIdList){
				User user = userService.findById(userId);
				cSQL[index] = "insert into T_UFP_BPM_NOTICE_RECEIVER(id,NOTICE_ID,RECEIVER_ID,RECEIVER_NAME) values('"+
				UUID.randomUUID().toString()+"','"+noticeId+"','"+user.getId()+"','"+user.getUsername()+"'";
				index++;
			}
			if(cSQL!=null && cSQL.length>0){
				noticeDao.batchNoticeReceiver(cSQL);
			}
		}
	}
	
	/**
	 * 保存角色信息
	 * @param roleIdList
	 * @param companyIdList
	 * @param noticeId
	 */
	private void saveNoticeRoleInfo(List<String> roleIdList,List<String> companyIdList,String noticeId){
		if(roleIdList!=null && roleIdList.size()>0){
			String cSQL[] = new String[roleIdList.size()];
			int index = 0;
			for(String roleId:roleIdList){
				Role role = roleService.findById(roleId);
				Org org = null;
				if(index<companyIdList.size()){
					org = orgService.findById(companyIdList.get(index));
				}
				cSQL[index] = "insert into T_UFP_BPM_NOTICE_ROLE(id,NOTICE_ID,ROLE_ID,ROLE_DESC,COMPANY_ID,COMPANY_NAME) values('"+
				UUID.randomUUID().toString()+"','"+noticeId+"','"+role.getId()+"','"+role.getName()+"',"+
						"'"+(org!=null?org.getCompanyId():null)+"','"+(org!=null?org.getCompanyName():null)+"'";
				index++;
			}
			if(cSQL!=null && cSQL.length>0){
				noticeDao.batchNoticeRole(cSQL);
			}
		}
	}
	@Override
	public Notice publish(String title, String content, String Url,String creatorId,
			List<String> roleIdList, List<String> companyIdList) {
		Notice notice = new Notice();
		User user = userService.findById(creatorId);
		notice.setCreateTime(new Date());
		notice.setTitle(title);
		notice.setContent(content);
		notice.setUrl(Url);
		notice.setSenderId(user.getId());
		notice.setSenderName(user.getUsername());
		noticeDao.save(notice);
		saveNoticeRoleInfo(roleIdList,companyIdList,notice.getId());
		return notice;
	}

	@Override
	public void updateToRead(String noticeId, String readUserId) {
		Notice notice = noticeDao.findById(noticeId);
		User user = userService.findById(readUserId);
		notice.setReadId(user.getId());
		notice.setReadName(user.getUsername());
		notice.setReadTime(new Date());
		noticeDao.update(notice);
	}

	@Override
	public void updateToDone(String noticeId, String doneUserId) {
		Notice notice = noticeDao.findById(noticeId);
		User user = userService.findById(doneUserId);
		notice.setDoneId(user.getId());
		notice.setDoneName(user.getUsername());
		notice.setFinishTime(new Date());
		noticeDao.update(notice);
	}

	@Override
	@RequestMapping("findByUserId")
	public List<Notice> queryByUserId(String userId) {
		 
		return noticeDao.queryByUserId(userId);
	}

	@Override
	public List<Notice> queryByRoleId(String roleId) {
		 
		return noticeDao.queryByRoleId(roleId);
	}

	@Override
	public List<Notice> queryByExample(Notice notice) {
		 
		return noticeDao.queryByExample(notice);
	}


}
