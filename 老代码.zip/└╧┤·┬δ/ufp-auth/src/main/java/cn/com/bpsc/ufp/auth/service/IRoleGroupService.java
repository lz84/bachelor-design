/*
 * @(#)IRoleService.java	Mar 18, 2013
 *
 * CopyrighRole (c) 2013, BPSC. All righRoles reserved.
 */
package cn.com.bpsc.ufp.auth.service;

import java.util.List;

import cn.com.bpsc.ufp.auth.domain.Role;
import cn.com.bpsc.ufp.auth.domain.RoleGroup;
import cn.com.bpsc.ufp.ps.domain.ProjectModule;



/**
 * @author
 *
 */
public interface IRoleGroupService {


	public void save(RoleGroup roleGroup);
	
	public void delete(RoleGroup roleGroup);
	
	public void saveOrUpdate(RoleGroup roleGroup);
	
	public void update(RoleGroup roleGroup);
	
	public RoleGroup findById(String id);
	
	public List<RoleGroup> findAll();
	
	public List<RoleGroup> findAllRoleInfo();
	
	public RoleGroup findByName(String roleName);

	public void deleteById(String id);
	
	public List<RoleGroup> findChildren(String parentModuleName) ;
}
