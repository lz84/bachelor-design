package cn.com.bpsc.demo.test.web;

public class TestPrivateMethod {

	public static void main(String[] args) {
		TestPrivateMethod outClass = new TestPrivateMethod();
		TestInnerClass inner = outClass.new TestInnerClass();
		inner.hello();
	}
	
	
	class TestInnerClass{
		private String hello(){
			System.out.println("in TestInnerClass.hello");
			return "hello";
		}
	}
}


