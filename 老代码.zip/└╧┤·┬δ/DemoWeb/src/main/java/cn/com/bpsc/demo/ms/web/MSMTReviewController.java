package cn.com.bpsc.demo.ms.web;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.com.bpsc.demo.ms.bp.MS_MT_ReviewParentBpDataEx;
import cn.com.bpsc.demo.ms.bp.MS_MT_ReviewSubBpDataEx;
import cn.com.bpsc.ufp.auth.service.ILoginService;
import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.bpm.domain.ReviewResult;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.bpm.vo.PiStatus;
import cn.com.bpsc.ufp.facade.service.IBpmContextService;
import cn.com.bpsc.ufp.org.domain.User;

/**
 * 多实例内嵌子流程Demo
 * 
 * 子流程包含会签节点、审核节点，以及审核退回会签节点的情况。
 * 
 */
@Controller
@RequestMapping("test/msmt")
public class MSMTReviewController {

	@Autowired
	private IBpmRuntimeService bpmRuntimeService;
	
	@Autowired
	private RepositoryService repositoryService;
	
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private RuntimeService runtimeService;
	
	@Autowired
	private ILoginService loginService;
	
	@Autowired
	private IBpmContextService bpmContext;
	
	private Log log = LogFactory.getLog(this.getClass());
	
	/**
	 * 启动流程
	 * uri:/test/msmt/start.htm?pdKey=ms_inline_hq_sh&bizKey={bizKey}
	 * @param pdkey
	 * @param bizkey
	 * @return
	 */
	@RequestMapping("start")
	@ResponseBody
	public Map<String,String> start(@RequestParam String pdKey, @RequestParam String bizKey){
		//登录，启动流程的前提条件
		loginService.login("c", "123456");
		
		//设置流程数据
		MS_MT_ReviewParentBpDataEx parent = new MS_MT_ReviewParentBpDataEx();
		parent.setDomainId(bizKey);
		parent.setBbzg("zhoulin");
		
		//第一个单位
		MS_MT_ReviewSubBpDataEx sub = new MS_MT_ReviewSubBpDataEx();
		//设置单位处长
		sub.setDwcz("lipengn");
		//设置单位专工
		sub.getDwzgList().add("c");
		sub.getDwzgList().add("wangzhaofengf");
		parent.getSubBpDataList().add(sub);
		
		//第二个单位
		sub = new MS_MT_ReviewSubBpDataEx();
		//设置单位处长
		sub.setDwcz("jinsonghua");
		//设置单位专工
		sub.getDwzgList().add("liuzhuo");
		sub.getDwzgList().add("qiaowanwan");
		sub.getDwzgList().add("zhuyanyan");
		parent.getSubBpDataList().add(sub);
		
		//启动流程
		ProcessInstance pi = bpmContext.startProcessInstanceByKey(pdKey, parent);
		
		//设置返回信息
		Map<String,String> result = new HashMap<String,String>();
		result.put("executionId", pi.getId());
		result.put("parentId", pi.getParentId());
		result.put("activityId", pi.getActivityId());
		result.put("pdId", pi.getProcessDefinitionId());
		result.put("piId", pi.getProcessInstanceId());
		result.put("bizKey", pi.getBusinessKey());
		
		log.debug(result);
		
		return result;
	}
	
	/**
	 * 本部专工发起
	 * uri:/test/msmt/bbfq.htm?bizKey={bizKey}
	 * @param bizKey
	 * @return
	 */
	@RequestMapping("bbfq")
	@ResponseBody
	public String bbfq(@RequestParam String bizKey){
		//以本部专工用户身份登录
		loginService.login("zhoulin", "123456");
		
		BaseBpDataEx bpData = bpmContext.getBpDataExByBizKey(bizKey);
		
		bpmRuntimeService.complete(bpData.getTaskEx().getTask().getId(), bpData);
		
		return "completed";
	}

	/**
	 * 单位专工填报
	 * uri:/test/msmt/dwzgtb.htm?bizKey={bizKey}&zgId={zgId}
	 * @param bizKey
	 * @param zgId
	 * @return
	 */
	@RequestMapping("dwzgtb")
	@ResponseBody
	public String dwzgtb(@RequestParam String bizKey, @RequestParam String zgId){
		//以单位专工用户身份登录
		loginService.login(zgId, "123456");
		
		BaseBpDataEx bpData = bpmContext.getBpDataExByBizKey(bizKey);
		
		bpmRuntimeService.complete(bpData.getTaskEx().getTask().getId(), bpData);
		
		return "completed";
	}
	
	/**
	 * 在子流程中终止整体流程
	 * uri:/test/msmt/stop.htm?bizKey={bizKey}&zgId={uesrId}
	 * @param bizKey
	 * @param zgId
	 * @return
	 */
	@RequestMapping("stop")
	@ResponseBody
	public String stop(@RequestParam String bizKey, @RequestParam String zgId){
		//以单位专工用户身份登录
		loginService.login(zgId, "123456");
		
		BaseBpDataEx bpData = bpmContext.getBpDataExByBizKey(bizKey);
		
		MS_MT_ReviewSubBpDataEx subBpData = 
				(MS_MT_ReviewSubBpDataEx)bpmContext.getPiVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData");
		subBpData.setResult("-1");
		bpmContext.setPiVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData", subBpData);
				
		bpmRuntimeService.complete(bpData.getTaskEx().getTask().getId(), bpData);
		
		return "completed";
	}
	
	/**
	 * 单位处长审核
	 * uri:/test/msmt/dwczsh.htm?bizKey={bizKey}&dwzcId={dwzcId}
	 * @param bizKey
	 * @param zgId
	 * @return
	 */
	@RequestMapping("dwczsh")
	@ResponseBody
	public String dwczsh(@RequestParam String bizKey, @RequestParam String dwzcId){
		//以单位处长用户身份登录
		loginService.login(dwzcId, "123456");
		
		BaseBpDataEx bpData = bpmContext.getBpDataExByBizKey(bizKey);
		MS_MT_ReviewSubBpDataEx subBpData = 
				(MS_MT_ReviewSubBpDataEx)bpmContext.getPiVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData");
		subBpData.setResult("1");
		bpmContext.setPiVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData", subBpData);
		
		bpmContext.completeReview(
				bpData.getTaskEx().getTask().getId(), 
				"审核标题", "审核内容", "审核注释", "无", 
				ReviewResult.pass.getName(), null, bpData);
		
		return "completed";
	}
	
	/**
	 * 单位处长退回
	 * uri:/test/msmt/dwczth.htm?bizKey={bizKey}&dwzcId={dwzcId}&thUserId={thUserId}
	 * @param bizKey
	 * @param zgId
	 * @return
	 */
	@RequestMapping("dwczth")
	@ResponseBody
	public String dwczth(@RequestParam String bizKey, @RequestParam String dwzcId, @RequestParam String thUserId){
		//以单位处长用户身份登录
		loginService.login(dwzcId, "123456");
		
		BaseBpDataEx bpData = bpmContext.getBpDataExByBizKey(bizKey);
		MS_MT_ReviewSubBpDataEx subBpData = 
				(MS_MT_ReviewSubBpDataEx)bpmContext.getPiVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData");
		
		subBpData.getDwzgList().clear();
		subBpData.getDwzgList().add(thUserId);
		subBpData.setResult("0");
		
		bpmContext.setPiVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData", subBpData);
		
		bpmContext.completeReview(
				bpData.getTaskEx().getTask().getId(), 
				"审核标题", "审核内容", "审核注释", "审核退回", 
				ReviewResult.unpass.getName(), null, bpData);
		
		return "completed";
	}
	
	/**
	 * 本部专工审核
	 * uri:/test/msmt/bbzgsh.htm?bizKey={bizKey}&bbzgId={bbzgId}
	 * @param bizKey
	 * @param zgId
	 * @return
	 */
	@RequestMapping("bbzgsh")
	@ResponseBody
	public String bbzgsh(@RequestParam String bizKey, @RequestParam String bbzgId){
		//以本部处长用户身份登录
		loginService.login(bbzgId, "123456");
		
		BaseBpDataEx bpData = bpmContext.getBpDataExByBizKey(bizKey);
		
		bpmRuntimeService.complete(bpData.getTaskEx().getTask().getId(), bpData);
		
		return "completed";
	}
	
	/**
	 * 根据bizKey查询待办人
	 * uri:/test/msmt/assignee.htm?bizKey={bizKey}&userId={userId}
	 * 
	 * @param bizKey
	 * @return
	 */
	@RequestMapping("assignee")
	@ResponseBody
	public List<User> queryAssigneerByBizKey(@RequestParam String bizKey, @RequestParam String userId){
		//以指定用户身份登录
		loginService.login(userId, "123456");
		
		List<User> users = bpmRuntimeService.getTaskCandidateUserByBizKey(bizKey);
			
		return users;
	}

	/**
	 * 根据bizKey查询BpDataEx
	 * uri:/test/msmt/baDataEx.htm?bizKey={bizKey}&userId={userId}
	 * 
	 * @param bizKey
	 * @return
	 */
	@RequestMapping("baDataEx")
	@ResponseBody
	public BaseBpDataEx getTaskByAssignee(@RequestParam String bizKey, @RequestParam String userId){
		//以指定用户身份登录
		loginService.login(userId, "123456");
		
		BaseBpDataEx bpData = bpmContext.getBpDataExByBizKey(bizKey);
		
		return bpData;
	}
	
	/**
	 * 根据bizKey和待办人，查询流程变量
	 * uri:/test/msmt/pv.htm?bizKey={bizKey}&userId={userId}
	 * 
	 * @param bizKey
	 * @return
	 */
	@RequestMapping("pv")
	@ResponseBody
	public String pvByBizKey(@RequestParam String bizKey, @RequestParam String userId){
		//以指定用户身份登录
		loginService.login(userId, "123456");
		BaseBpDataEx bpData = bpmRuntimeService.getBpDataExByBizKey(bizKey);
		
		Object obj = bpmRuntimeService.getPiVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData");
		Object obj1 = runtimeService.getVariable(bpData.getTaskEx().getTask().getExecutionId(), "subBpData");
		
		Map<String,Object> map1 = runtimeService.getVariables(bpData.getTaskEx().getTask().getExecutionId());
		
		Map<String,Object> map2 = runtimeService.getVariablesLocal(bpData.getTaskEx().getTask().getExecutionId());
		
		return "ok";
	}
	
	
	
	/**
	 * 根据bizKey查询待办信息
	 * uri:/test/msmt/taskName.htm?bizKey={bizKey}
	 * 
	 * @param bizKey
	 * @return
	 */
	@RequestMapping("taskName")
	@ResponseBody
	public List<String> queryTaskByBizKey(@RequestParam String bizKey){
		TaskQuery query = taskService.createTaskQuery();
		List<Task> taskList = query.processInstanceBusinessKey(bizKey).list();
		List<String> tasks = new ArrayList<String>();
		if(taskList != null && !taskList.isEmpty()){
			for(Task task : taskList){
				tasks.add(task.getName()+ ":" + task.getAssignee());
			}
		}
		return tasks;
	}
	
	/**
	 * 流程状态
	 * uri:/test/msmt/piStatus.htm?bizKey={bizKey}
	 * 
	 * @param bizKey
	 * @return
	 */
	@RequestMapping("piStatus")
	@ResponseBody
	public PiStatus piStatus(@RequestParam String bizKey){
		PiStatus piStatus = bpmContext.getPiStatusByBizKey(bizKey);
		
		return piStatus;
	}
	
	/**
	 * 流程部署
	 * uri:/test/msmt/deploy.htm
	 * 
	 * @return
	 */
	@RequestMapping("deploy")
	@ResponseBody
	public String deploy(){
		ZipInputStream inputStream = null;
		Deployment deploy = null;
		try {
			//注意：修改部署包为相应的路径。
			String barFileName = "D:\\dev-tools\\eclipse\\workspace\\activiti\\deployment\\dwhq_parent.bar"; 
			inputStream = new ZipInputStream(new FileInputStream(barFileName)); 
			 
			deploy = repositoryService.createDeployment() 
			    .name("ms_process.bar") 
			    .addZipInputStream(inputStream) 
			    .deploy(); 

			
			System.out.println("流程部署成功！ id:" + deploy.getId() + ",name:" + deploy.getName() + ", time:" + deploy.getDeploymentTime());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return "error";
		} finally{
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return "ok! id:" + deploy.getId() + ",name:" + deploy.getName() + ", time:" + deploy.getDeploymentTime();
	}
}
