/**
 * 
 */
package cn.hypersoft.demo.web;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author DELL
 * 
 */
@Controller
public class SecurityController {

	@RequestMapping("/security")
	@ResponseBody
	String home(String name) {

		return "Welcome "
				+ SecurityContextHolder.getContext().getAuthentication()
						.getPrincipal() + "!";
	}
}
