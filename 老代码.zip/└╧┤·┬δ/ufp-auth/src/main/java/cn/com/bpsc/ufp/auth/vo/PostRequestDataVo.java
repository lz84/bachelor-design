package cn.com.bpsc.ufp.auth.vo;

public class PostRequestDataVo {

 
	private String authFuncs;

	public String getAuthFuncs() {
		return authFuncs;
	}

	public void setAuthFuncs(String authFuncs) {
		this.authFuncs = authFuncs;
	}
	
	
}
