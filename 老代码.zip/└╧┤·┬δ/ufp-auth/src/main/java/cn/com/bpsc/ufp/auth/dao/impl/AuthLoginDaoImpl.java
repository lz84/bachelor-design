package cn.com.bpsc.ufp.auth.dao.impl;

import java.util.List;
import org.springframework.stereotype.Repository;
import cn.com.bpsc.ufp.auth.dao.IAuthLoginDao;
import cn.com.bpsc.ufp.auth.domain.AuthLogin;
import cn.com.bpsc.ufp.dao.impl.GenericDaoImpl;

@Repository
public class AuthLoginDaoImpl extends GenericDaoImpl<AuthLogin, String>  implements IAuthLoginDao {

	@Override
	public List<AuthLogin> findByExample(AuthLogin al) {
		
		return null;
	}

}
