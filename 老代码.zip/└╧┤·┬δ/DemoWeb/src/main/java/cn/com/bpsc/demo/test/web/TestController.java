package cn.com.bpsc.demo.test.web;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

import org.activiti.engine.RepositoryService;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.com.bpsc.aqzs.common.service.IProcessService;
import cn.com.bpsc.aqzs.common.util.ApplicationContextHolder;
import cn.com.bpsc.demo.risklevel.bp.PNRiskLevelBpDataEx;
import cn.com.bpsc.demo.risklevel.vo.BaseBpDataExVo;
import cn.com.bpsc.demo.subproc.biz.ITestSubProcessService;
import cn.com.bpsc.demo.test.ws.IEchoWs;
import cn.com.bpsc.ufp.bpm.domain.BaseBpDataEx;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeService;
import cn.com.bpsc.ufp.bpm.service.IBpmRuntimeTaskService;
import cn.com.bpsc.ufp.facade.service.IBpmContextService;
import cn.com.bpsc.ufp.facade.service.ITaskGraphicDataService;
import cn.com.bpsc.ufp.org.dao.IUserDao;
import cn.com.bpsc.ufp.org.domain.User;

@Controller
@RequestMapping("test")
public class TestController implements ApplicationContextAware{

	@Autowired
	private IBpmRuntimeTaskService bpmTaskRuntime;
	
	@Autowired
	private IBpmRuntimeService bpmRuntime;
	
	@Autowired
	private IBpmContextService bpmCtx;
	
	@Autowired
	private ITaskGraphicDataService taskGraphicDataService;
	
	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private RepositoryService repositoryService;
	
	@RequestMapping("pd")
	@ResponseBody
	public String pd(String pdId){
		bpmTaskRuntime.getFirstTask(pdId);
		
		return "ok";
	}
	
	@RequestMapping("allUser")
	@ResponseBody	
	public List<User> allUser(){
		return userDao.findAll();
	}
	
	
	@RequestMapping("assignee")
	@ResponseBody
	public List<User> assignee(String bizKey){
		return bpmCtx.getTaskCandidateUserByBizKey(bizKey);
		
	}
	
	@RequestMapping("findGraphicByBizKey")
	@ResponseBody
	public Map<String,Object> findGraphicByBizKey(String bizKey){
		return taskGraphicDataService.findByBizKey(bizKey);
	}
	
	@RequestMapping("getBpDataEx")
	@ResponseBody
	public List<BaseBpDataExVo> getBpDataEx(String candidateUserId, String pdKey){
		Long startTime = System.currentTimeMillis();
		List<BaseBpDataEx> bpDataExs = bpmTaskRuntime.getBpDataExByCandidateUser(pdKey,candidateUserId);
		System.out.println("getBpDataExByCandidateUser方法消耗时间:"+(System.currentTimeMillis()-startTime)+"毫秒\n返回集合数值:"+bpDataExs.size());
		BaseBpDataExVo bpDataExVo ;
		List<BaseBpDataExVo> bpDataExVos = new ArrayList<BaseBpDataExVo>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for(BaseBpDataEx bpDataEx : bpDataExs){
			bpDataExVo = new BaseBpDataExVo();
			bpDataExVo.setPiId(bpDataEx.getPiId());
			bpDataExVo.setTaskCreateTime(sdf.format(bpDataEx.getTaskEx().getTask().getCreateTime()));
			bpDataExVo.setTaskName(bpDataEx.getTaskEx().getTask().getName());
			bpDataExVos.add(bpDataExVo);
		}
		return bpDataExVos;
	}
	
	@RequestMapping("getBpDataExByAssignee")
	@ResponseBody
	public List<BaseBpDataExVo> getBpDataExByAssignee(String assignee, String pdKey){
		Long startTime = System.currentTimeMillis();
		List<BaseBpDataEx> bpDataExs = bpmTaskRuntime.getBpDataExByAssignee(pdKey,assignee);
		System.out.println("getBpDataExByCandidateUser方法消耗时间:"+(System.currentTimeMillis()-startTime)+"毫秒\n返回集合数值:"+bpDataExs.size());
		BaseBpDataExVo bpDataExVo ;
		List<BaseBpDataExVo> bpDataExVos = new ArrayList<BaseBpDataExVo>();
		for(BaseBpDataEx bpDataEx : bpDataExs){
			bpDataExVo = new BaseBpDataExVo();
			bpDataExVo.setPiId(bpDataEx.getPiId());
			bpDataExVo.setTaskName(bpDataEx.getTaskEx().getTask().getName());
			bpDataExVos.add(bpDataExVo);
		}
		return bpDataExVos;
	}
	
	@RequestMapping("encoding/show")
	public ModelAndView encodingShow(){
		return new ModelAndView("test/encoding");
	}
	
	@RequestMapping("encoding/get")
	public ModelAndView encodingGet(String userId1,String userName1){
		
		/**
		 * 
		 <Connector port="8080" protocol="HTTP/1.1" 
               connectionTimeout="20000" 
               redirectPort="8443" URIEncoding="utf-8" useBodyEncodingForURI="true"/>
		 * 
		 * 
		 */
		
		
		Map<String,String> map = new HashMap<String,String>();
		
		map.put("userName1", userName1);
		map.put("userId1", userId1);
		ModelAndView mav =  new ModelAndView("test/encoding","model1",map);
		return mav;
	}
	
	@RequestMapping("encoding/post")
	public ModelAndView encodingPost(String userId2, String userName2){
		Map<String,String> map = new HashMap<String,String>();
		
		map.put("userName2", userName2);
		map.put("userId2", userId2);
		ModelAndView mav =  new ModelAndView("test/encoding","model2",map);
		
		return mav;
	}
	
	@RequestMapping("cadidate")
	@ResponseBody
	public List<User> getTaskCandidate(String piId,String taskDefKey){
		//piId = "12101"
		//taskDefKey = "multiReview";
		List<User> users = bpmRuntime.getTaskCandidateUserByDefKey(piId, taskDefKey);
		return users;
	}
	
	@RequestMapping("setbp")
	@ResponseBody
	public String setBpDataEx(){
		PNRiskLevelBpDataEx bpdata = (PNRiskLevelBpDataEx)bpmRuntime.getBpDataEx("12101");
		ArrayList<String> list = new ArrayList<String>(1);
		list.add("test");
		bpdata.setAssigneeList(list);
		//bpmRuntime.complete();
		return "ok";
	}
	
	@RequestMapping("getbp")
	@ResponseBody
	public PNRiskLevelBpDataEx getBpDataEx(){
		PNRiskLevelBpDataEx bpdata = (PNRiskLevelBpDataEx)bpmRuntime.getBpDataEx("12101");
		
		return bpdata;
	}

	@RequestMapping("ws")
	@ResponseBody
	public String testWs(){
		IEchoWs helloService = (IEchoWs) appCtx.getBean("echoServiceClient");  
		String username = "CXF";  
		// 调用方法进行服务消费  
		String result = helloService.echo(username);
		System.out.println("Result:" + result); 
		
		return result;
	}

	@Autowired
	private ITestSubProcessService spService;
	
	@RequestMapping("callsp")
	@ResponseBody
	public String callSP(){
		spService.start();
		
		return "started";
	}
	
	private ApplicationContext appCtx;
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.appCtx = applicationContext;
		
	}
	
	@RequestMapping("callsp2")
	@ResponseBody
	public boolean startProcess(boolean isWeek){
		IProcessService service = (IProcessService) ApplicationContextHolder.getApplicationContext().getBean("processServiceClient"); 
		// 调用方法进行服务消费  
		boolean b = service.startProcessCj(isWeek, "c", "123456");
		System.out.println("Result:" + b); 
		//startProcess("startProcessCj", isWeek, "system", "1");
		return b;
	}
	
	@RequestMapping("deploy")
	@ResponseBody
	public String deploy(){
		ZipInputStream inputStream = null;
		try {
			String barFileName = "D:\\dev-tools\\eclipse\\workspace\\activiti\\deployment\\dwhq_parent.bar"; 
			inputStream = new ZipInputStream(new FileInputStream(barFileName)); 
			 
			repositoryService.createDeployment() 
			    .name("ms_process.bar") 
			    .addZipInputStream(inputStream) 
			    .deploy(); 

			
			System.out.println("OK...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "error";
		} finally{
			try {
				inputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return "ok";
	}
	
	@RequestMapping("deletePi")
	@ResponseBody
	public String deletePi(@RequestParam String piId){
		bpmRuntime.deleteProcessInstance(piId, "测试删除");
		
		return "deleted";
	}
}
