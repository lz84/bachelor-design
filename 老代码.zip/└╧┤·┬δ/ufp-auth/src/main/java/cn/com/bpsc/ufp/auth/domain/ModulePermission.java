/*
 * @(#)ModulePermission.java	Mar 19, 2013
 *
 * Copyright (c) 2013, BPSC. All rights reserved.
 */
package cn.com.bpsc.ufp.auth.domain;

/**
 * @author
 *
 */
public class ModulePermission extends AbstractPermission {

}
